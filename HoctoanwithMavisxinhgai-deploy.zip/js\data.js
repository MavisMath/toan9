// ================================================================
// DỮ LIỆU ĐẤU TRƯỜNG TOÁN 9 - CHƯƠNG TRÌNH GDPT 2018
// Cập nhật mới nhất: Ôn tập Học kỳ & Luyện thi vào lớp 10
// ================================================================

const TOPICS = [
  {
    id: 'can_thuc',
    name: 'Căn thức & Rút gọn',
    icon: '√x',
    description: 'Căn bậc hai, căn bậc ba, điều kiện xác định, hằng đẳng thức và rút gọn biểu thức',
    color: 'from-amber-500 to-orange-600',
    borderColor: 'border-amber-500',
    badge: 'Đại số 9'
  },
  {
    id: 'he_phuong_trinh',
    name: 'Hệ hai phương trình',
    icon: '{xy}',
    description: 'Hệ phương trình bậc nhất hai ẩn, giải hệ bằng phương pháp thế, cộng đại số và toán thực tế',
    color: 'from-blue-500 to-indigo-600',
    borderColor: 'border-blue-500',
    badge: 'Đại số 9'
  },
  {
    id: 'bat_phuong_trinh',
    name: 'Bất đẳng thức & BPT',
    icon: '≥ ≤',
    description: 'Liên hệ thứ tự, bất phương trình bậc nhất một ẩn, bất đẳng thức AM-GM thực tế',
    color: 'from-emerald-500 to-teal-600',
    borderColor: 'border-emerald-500',
    badge: 'Đại số 9'
  },
  {
    id: 'he_thuc_luong',
    name: 'Hệ thức lượng & Lượng giác',
    icon: '📐',
    description: 'Hệ thức lượng trong tam giác vuông, tỉ số lượng giác sin, cos, tan và bài toán đo đạc thực tế',
    color: 'from-cyan-500 to-blue-600',
    borderColor: 'border-cyan-500',
    badge: 'Hình học 9'
  },
  {
    id: 'duong_tron',
    name: 'Đường tròn & Tiếp tuyến',
    icon: '⭕',
    description: 'Đường kính và dây cung, tiếp tuyến của đường tròn, tính chất hai tiếp tuyến cắt nhau',
    color: 'from-rose-500 to-pink-600',
    borderColor: 'border-rose-500',
    badge: 'Hình học 9'
  },
  {
    id: 'ham_so_bac_hai',
    name: 'Hàm số $y=ax^2$ & Phương trình bậc hai',
    icon: '📈',
    description: 'Đồ thị Parabol, giải phương trình bậc hai $ax^2+bx+c=0$, biệt thức $\\Delta$',
    color: 'from-purple-500 to-violet-600',
    borderColor: 'border-purple-500',
    badge: 'Đại số 9'
  },
  {
    id: 'he_thuc_viet',
    name: 'Định lý Vi-ét & Ứng dụng',
    icon: 'x₁x₂',
    description: 'Hệ thức Vi-ét, nhẩm nghiệm, tìm hai số khi biết tổng và tích, xét dấu các nghiệm',
    color: 'from-fuchsia-500 to-pink-600',
    borderColor: 'border-fuchsia-500',
    badge: 'Đại số 9'
  },
  {
    id: 'goc_duong_tron',
    name: 'Góc với đường tròn & Tứ giác nội tiếp',
    icon: '🎯',
    description: 'Góc ở tâm, góc nội tiếp, tứ giác nội tiếp đường tròn và các dấu hiệu nhận biết',
    color: 'from-indigo-500 to-purple-600',
    borderColor: 'border-indigo-500',
    badge: 'Hình học 9'
  },
  {
    id: 'hinh_khong_gian',
    name: 'Hình trụ - Hình nón - Hình cầu',
    icon: '🧊',
    description: 'Diện tích xung quanh, thể tích các hình khối không gian trong đời sống thực tế',
    color: 'from-teal-500 to-emerald-600',
    borderColor: 'border-teal-500',
    badge: 'Hình học 9'
  },
  {
    id: 'xac_suat_thong_ke',
    name: 'Xác suất & Thống kê 9',
    icon: '📊',
    description: 'Bảng tần số, tần số tương đối, biểu đồ cột, biểu đồ quạt và xác suất biến cố',
    color: 'from-sky-500 to-cyan-600',
    borderColor: 'border-sky-500',
    badge: 'Xác suất 9'
  }
];

// DỮ LIỆU CÂU HỎI THEO CHUYÊN ĐỀ & ĐỀ KIỂM TRA
const QUESTIONS = [
  // ==========================================
  // CHỦ ĐỀ 1: CĂN THỨC & RÚT GỌN
  // ==========================================
  {
    id: 'ct_01',
    topicId: 'can_thuc',
    title: 'Điều kiện xác định của căn bậc hai',
    content: 'Biểu thức $\\sqrt{2x - 6}$ xác định khi và chỉ khi:',
    options: [
      '$x \\ge 3$',
      '$x > 3$',
      '$x \\le 3$',
      '$x \\ge -3$'
    ],
    correctAnswer: 0,
    explanation: 'Biểu thức $\\sqrt{A}$ xác định $\\Leftrightarrow A \\ge 0$.\nTa có: $2x - 6 \\ge 0 \\Leftrightarrow 2x \\ge 6 \\Leftrightarrow x \\ge 3$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'ct_02',
    topicId: 'can_thuc',
    title: 'Hằng đẳng thức căn bậc hai',
    content: 'Giá trị của biểu thức $\\sqrt{(\\sqrt{5} - 3)^2} + \\sqrt{5}$ bằng:',
    options: [
      '$2\\sqrt{5} - 3$',
      '$3$',
      '$-3$',
      '$6 - \\sqrt{5}$'
    ],
    correctAnswer: 1,
    explanation: 'Ta có $\\sqrt{A^2} = |A|$.\nVì $\\sqrt{5} < \\sqrt{9} = 3 \\Rightarrow \\sqrt{5} - 3 < 0$.\nDo đó $\\sqrt{(\\sqrt{5} - 3)^2} = |\\sqrt{5} - 3| = 3 - \\sqrt{5}$.\nSuy ra: $(3 - \\sqrt{5}) + \\sqrt{5} = 3$.',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'ct_03',
    topicId: 'can_thuc',
    title: 'Tính giá trị biểu thức căn bậc hai',
    content: 'Kết quả của phép tính $\\sqrt{20} - \\sqrt{45} + 2\\sqrt{5}$ là:',
    options: [
      '$\\sqrt{5}$',
      '$3\\sqrt{5}$',
      '$-\\\\sqrt{5}$',
      '$5$'
    ],
    correctAnswer: 0,
    explanation: '$\\sqrt{20} = \\sqrt{4 \\cdot 5} = 2\\sqrt{5}$.\n$\\sqrt{45} = \\sqrt{9 \\cdot 5} = 3\\sqrt{5}$.\nVậy $2\\sqrt{5} - 3\\sqrt{5} + 2\\sqrt{5} = (2 - 3 + 2)\\sqrt{5} = \\sqrt{5}$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'ct_04',
    topicId: 'can_thuc',
    title: 'Khử căn thức ở mẫu',
    content: 'Trục căn thức ở mẫu của biểu thức $\\frac{6}{\\sqrt{5} - \\sqrt{2}}$ ta được:',
    options: [
      '$2(\\sqrt{5} + \\sqrt{2})$',
      '$3(\\sqrt{5} + \\sqrt{2})$',
      '$\\frac{6(\\sqrt{5} - \\sqrt{2})}{3}$',
      '$\\sqrt{5} + \\sqrt{2}$'
    ],
    correctAnswer: 0,
    explanation: 'Nhân cả tử và mẫu với lượng liên hợp $(\\sqrt{5} + \\sqrt{2})$:\n$\\frac{6(\\sqrt{5} + \\sqrt{2})}{(\\sqrt{5})^2 - (\\sqrt{2})^2} = \\frac{6(\\sqrt{5} + \\sqrt{2})}{5 - 2} = \\frac{6(\\sqrt{5} + \\sqrt{2})}{3} = 2(\\sqrt{5} + \\sqrt{2})$.',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'ct_05',
    topicId: 'can_thuc',
    title: 'Rút gọn biểu thức chứa căn',
    content: 'Với $x \\ge 0, x \\ne 1$, rút gọn biểu thức $P = \\left(\\frac{1}{\\sqrt{x}-1} - \\frac{1}{\\sqrt{x}+1}\\right) \\cdot \\frac{x-1}{2}$:',
    options: [
      '$1$',
      '$\\sqrt{x}$',
      '$2$',
      '$\\frac{1}{x-1}$'
    ],
    correctAnswer: 0,
    explanation: 'Quy đồng trong ngoặc:\n$\\frac{(\\sqrt{x}+1) - (\\sqrt{x}-1)}{(\\sqrt{x}-1)(\\sqrt{x}+1)} = \\frac{2}{x-1}$.\nNhân với $\\frac{x-1}{2}$ ta được: $\\frac{2}{x-1} \\cdot \\frac{x-1}{2} = 1$.',
    difficulty: 'hard',
    points: 20
  },
  {
    id: 'ct_06',
    topicId: 'can_thuc',
    title: 'Căn bậc ba',
    content: 'Giá trị của biểu thức $\\sqrt[3]{64} - \\sqrt[3]{-27}$ là:',
    options: [
      '$7$',
      '$1$',
      '$-1$',
      '$37$'
    ],
    correctAnswer: 0,
    explanation: '$\\sqrt[3]{64} = 4$, $\\sqrt[3]{-27} = -3$.\nVậy $4 - (-3) = 4 + 3 = 7$.',
    difficulty: 'easy',
    points: 10
  },

  // ==========================================
  // CHỦ ĐỀ 2: HỆ PHƯƠNG TRÌNH BẬC NHẤT HAI ẨN
  // ==========================================
  {
    id: 'hpt_01',
    topicId: 'he_phuong_trinh',
    title: 'Nhận biết phương trình bậc nhất hai ẩn',
    content: 'Trong các phương trình sau, phương trình nào KHÔNG PHẢI là phương trình bậc nhất hai ẩn?',
    options: [
      '$0x - 0y = 4$',
      '$-3x + 3y = 3$',
      '$0x - 2y = 0$',
      '$3x + 0y = 1$'
    ],
    correctAnswer: 0,
    explanation: 'Phương trình bậc nhất hai ẩn có dạng $ax + by = c$, trong đó $a$ và $b$ không đồng thời bằng 0.\nPhương trình $0x - 0y = 4$ có cả $a=0$ và $b=0$ nên không phải là phương trình bậc nhất hai ẩn.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'hpt_02',
    topicId: 'he_phuong_trinh',
    title: 'Giải hệ phương trình cơ bản',
    content: 'Hệ phương trình $\\begin{cases} 2x + y = 5 \\\\ x - y = 1 \\end{cases}$ có nghiệm $(x; y)$ là:',
    options: [
      '$(2; 1)$',
      '$(1; 2)$',
      '$(3; -1)$',
      '$(0; 5)$'
    ],
    correctAnswer: 0,
    explanation: 'Cộng từng vế hai phương trình:\n$(2x + y) + (x - y) = 5 + 1 \\Leftrightarrow 3x = 6 \\Leftrightarrow x = 2$.\nThay $x = 2$ vào $x - y = 1 \\Rightarrow 2 - y = 1 \\Leftrightarrow y = 1$.\nVậy nghiệm là $(2; 1)$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'hpt_03',
    topicId: 'he_phuong_trinh',
    title: 'Giải hệ phương trình bằng phương pháp thế',
    content: 'Hệ phương trình $\\begin{cases} 3x - 2y = 7 \\\\ 2x + 3y = 9 \\end{cases}$ có nghiệm duy nhất là:',
    options: [
      '$(3; 1)$',
      '$(1; 3)$',
      '$(2; -0.5)$',
      '$(3; -1)$'
    ],
    correctAnswer: 0,
    explanation: 'Nhân PT(1) với 3 và PT(2) với 2:\n$\\begin{cases} 9x - 6y = 21 \\\\ 4x + 6y = 18 \\end{cases}$\nCộng lại: $13x = 39 \\Rightarrow x = 3$.\nThay vào: $3(3) - 2y = 7 \\Rightarrow 9 - 2y = 7 \\Rightarrow y = 1$.\nVậy nghiệm $(x; y) = (3; 1)$.',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'hpt_04',
    topicId: 'he_phuong_trinh',
    title: 'Toán thực tế lập hệ phương trình',
    content: 'Hai lớp 9A và 9B quyên góp sách ủng hộ vùng lũ được tổng cộng 250 cuốn sách. Biết lớp 9A ủng hộ nhiều hơn lớp 9B là 30 cuốn. Số sách lớp 9A và 9B ủng hộ lần lượt là:',
    options: [
      '140 cuốn và 110 cuốn',
      '130 cuốn và 120 cuốn',
      '150 cuốn và 100 cuốn',
      '145 cuốn và 105 cuốn'
    ],
    correctAnswer: 0,
    explanation: 'Gọi $x, y$ lần lượt là số sách của 9A và 9B ($x, y \\in \\mathbb{N}^*$).\nTa có hệ PT: $\\begin{cases} x + y = 250 \\\\ x - y = 30 \\end{cases}$\nCộng hai PT: $2x = 280 \\Rightarrow x = 140$.\nSuy ra $y = 250 - 140 = 110$.\nVậy lớp 9A có 140 cuốn, lớp 9B có 110 cuốn.',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'hpt_05',
    topicId: 'he_phuong_trinh',
    title: 'Tìm tham số m để hệ có nghiệm',
    content: 'Cho hệ phương trình $\\begin{cases} mx + y = 3 \\\\ x + y = 1 \\end{cases}$. Hệ vô nghiệm khi $m$ bằng:',
    options: [
      '$m = 1$',
      '$m = -1$',
      '$m = 3$',
      '$m \\ne 1$'
    ],
    correctAnswer: 0,
    explanation: 'Hệ phương trình $\\begin{cases} a_1 x + b_1 y = c_1 \\\\ a_2 x + b_2 y = c_2 \\end{cases}$ vô nghiệm khi $\\frac{a_1}{a_2} = \\frac{b_1}{b_2} \\ne \\frac{c_1}{c_2}$.\nTa có $\\frac{m}{1} = \\frac{1}{1} \\ne \\frac{3}{1} \\Leftrightarrow m = 1$.',
    difficulty: 'hard',
    points: 20
  },

  // ==========================================
  // CHỦ ĐỀ 3: BẤT ĐẲNG THỨC & BẤT PHƯƠNG TRÌNH
  // ==========================================
  {
    id: 'bpt_01',
    topicId: 'bat_phuong_trinh',
    title: 'Tính chất bất đẳng thức',
    content: 'Cho $a < b$, khẳng định nào sau đây luôn ĐÚNG?',
    options: [
      '$-3a + 5 > -3b + 5$',
      '$2a - 1 > 2b - 1$',
      '$-2a < -2b$',
      '$a^2 < b^2$'
    ],
    correctAnswer: 0,
    explanation: 'Khi nhân cả hai vế của một bất đẳng thức với một số âm, ta phải đổi chiều bất đẳng thức:\n$a < b \\Rightarrow -3a > -3b \\Rightarrow -3a + 5 > -3b + 5$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'bpt_02',
    topicId: 'bat_phuong_trinh',
    title: 'Giải bất phương trình bậc nhất một ẩn',
    content: 'Tập nghiệm của bất phương trình $3x - 5 \\ge x + 3$ là:',
    options: [
      '$x \\ge 4$',
      '$x > 4$',
      '$x \\le 4$',
      '$x \\ge 1$'
    ],
    correctAnswer: 0,
    explanation: '$3x - x \\ge 3 + 5 \\Leftrightarrow 2x \\ge 8 \\Leftrightarrow x \\ge 4$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'bpt_03',
    topicId: 'bat_phuong_trinh',
    title: 'Bất đẳng thức Cauchy (AM-GM)',
    content: 'Cho số thực $x > 0$. Giá trị nhỏ nhất của biểu thức $P = x + \\frac{4}{x}$ là:',
    options: [
      '$4$',
      '$2$',
      '$8$',
      '$16$'
    ],
    correctAnswer: 0,
    explanation: 'Áp dụng BĐT Cauchy (AM-GM) cho hai số dương $x$ và $\\frac{4}{x}$:\n$x + \\frac{4}{x} \\ge 2\\sqrt{x \\cdot \\frac{4}{x}} = 2\\sqrt{4} = 4$.\nDấu bằng xảy ra khi $x = \\frac{4}{x} \\Leftrightarrow x^2 = 4 \\Leftrightarrow x = 2$ (do $x > 0$).\nVậy GTNN là 4.',
    difficulty: 'hard',
    points: 20
  },

  // ==========================================
  // CHỦ ĐỀ 4: HỆ THỨC LƯỢNG & TỈ SỐ LƯỢNG GIÁC
  // ==========================================
  {
    id: 'htl_01',
    topicId: 'he_thuc_luong',
    title: 'Hệ thức cạnh và hình chiếu trong tam giác vuông',
    content: 'Cho $\\triangle ABC$ vuông tại $A$, đường cao $AH$. Khẳng định nào sau đây là ĐÚNG?',
    options: [
      '$AH^2 = BH \\cdot CH$',
      '$AB^2 = BH \\cdot AH$',
      '$AH \\cdot BC = AB^2$',
      '$\\frac{1}{AH^2} = \\frac{1}{AB^2} - \\frac{1}{AC^2}$'
    ],
    correctAnswer: 0,
    explanation: 'Theo các hệ thức lượng trong tam giác vuông:\n- $AH^2 = BH \\cdot CH$ (Bình phương đường cao bằng tích hai hình chiếu).\n- $AB^2 = BH \\cdot BC$.\n- $AB \\cdot AC = AH \\cdot BC$.\n- $\\frac{1}{AH^2} = \\frac{1}{AB^2} + \\frac{1}{AC^2}$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'htl_02',
    topicId: 'he_thuc_luong',
    title: 'Định nghĩa tỉ số lượng giác góc nhọn',
    content: 'Cho $\\triangle ABC$ vuông tại $A$ có $AB = 6\\text{ cm}, BC = 10\\text{ cm}$. Giá trị của $\\cos B$ bằng:',
    options: [
      '$0{,}6$',
      '$0{,}8$',
      '$\\frac{4}{3}$',
      '$\\frac{3}{4}$'
    ],
    correctAnswer: 0,
    explanation: 'Trong tam giác vuông, $\\cos B = \\frac{\\text{cạnh kề}}{\\text{cạnh huyền}} = \\frac{AB}{BC} = \\frac{6}{10} = 0{,}6$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'htl_03',
    topicId: 'he_thuc_luong',
    title: 'Bài toán thực tế tỉ số lượng giác',
    content: 'Một chiếc máy bay bay lên được quãng đường $10\\text{ km}$ theo phương nghiêng tạo với mặt đất góc $20^\\circ$. Hỏi máy bay cách mặt đất bao nhiêu kilômét? (Biết $\\sin 20^\\circ \\approx 0{,}342$)',
    options: [
      '$3{,}4\\text{ km}$',
      '$3{,}5\\text{ km}$',
      '$3{,}3\\text{ km}$',
      '$9{,}4\\text{ km}$'
    ],
    correctAnswer: 0,
    explanation: 'Gọi $h$ là độ cao của máy bay. Ta có tam giác vuông với cạnh huyền là $10\\text{ km}$ và góc đối là $20^\\circ$.\n$h = 10 \\cdot \\sin 20^\\circ \\approx 10 \\cdot 0{,}342 = 3{,}42 \\approx 3{,}4\\text{ km}$.',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'htl_04',
    topicId: 'he_thuc_luong',
    title: 'Hệ thức liên hệ giữa các tỉ số lượng giác',
    content: 'Biết $\\sin \\alpha = 0{,}6$ ($0^\\circ < \\alpha < 90^\\circ$). Giá trị của $\\tan \\alpha$ là:',
    options: [
      '$\\frac{3}{4}$',
      '$\\frac{4}{3}$',
      '$0{,}8$',
      '$\\frac{4}{5}$'
    ],
    correctAnswer: 0,
    explanation: 'Ta có $\\cos^2 \\alpha = 1 - \\sin^2 \\alpha = 1 - 0{,}36 = 0{,}64 \\Rightarrow \\cos \\alpha = 0{,}8$.\nDo đó $\\tan \\alpha = \\frac{\\sin \\alpha}{\\cos \\alpha} = \\frac{0{,}6}{0{,}8} = \\frac{3}{4}$.',
    difficulty: 'medium',
    points: 15
  },

  // ==========================================
  // CHỦ ĐỀ 5: ĐƯỜNG TRÒN & TIẾP TUYẾN
  // ==========================================
  {
    id: 'dt_01',
    topicId: 'duong_tron',
    title: 'Định nghĩa tiếp tuyến của đường tròn',
    content: 'Đường thẳng $d$ là tiếp tuyến của đường tròn $(O; R)$ tại điểm $M$ khi và chỉ khi:',
    options: [
      '$d \\perp OM$ tại $M$ và $M \\in (O)$',
      '$d$ đi qua tâm $O$',
      '$d$ cắt đường tròn tại hai điểm phân biệt',
      'Khoảng cách từ $O$ đến $d$ nhỏ hơn $R$'
    ],
    correctAnswer: 0,
    explanation: 'Tiếp tuyến của đường tròn là đường thẳng vuông góc với bán kính đi qua tiếp điểm.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'dt_02',
    topicId: 'duong_tron',
    title: 'Vị trí tương đối của hai đường tròn',
    content: 'Cho hai đường tròn $(O; 5\\text{ cm})$ và $(O\'; 3\\text{ cm})$. Nếu đoạn nối tâm $OO\' = 8\\text{ cm}$ thì hai đường tròn:',
    options: [
      'Tiếp xúc ngoài',
      'Tiếp xúc trong',
      'Cắt nhau',
      'Ở ngoài nhau'
    ],
    correctAnswer: 0,
    explanation: 'Ta có $R_1 + R_2 = 5 + 3 = 8\\text{ cm} = OO\'$.\nKhi đoạn nối tâm bằng tổng hai bán kính thì hai đường tròn tiếp xúc ngoài nhau.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'dt_03',
    topicId: 'duong_tron',
    title: 'Tính chất hai tiếp tuyến cắt nhau',
    content: 'Từ điểm $A$ nằm ngoài $(O; R)$, kẻ hai tiếp tuyến $AB, AC$ với $(O)$ ($B, C$ là các tiếp điểm). Khẳng định nào sau đây SAI?',
    options: [
      '$AO \\parallel BC$',
      '$AB = AC$',
      '$AO$ là tia phân giác của $\\widehat{BAC}$',
      '$AO$ là đường trung trực của đoạn thẳng $BC$'
    ],
    correctAnswer: 0,
    explanation: 'Theo tính chất hai tiếp tuyến cắt nhau, $AO$ vuông góc với $BC$ tại trung điểm của $BC$ (chứ không phải song song).',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'dt_04',
    topicId: 'duong_tron',
    title: 'Quan hệ đường kính và dây cung',
    content: 'Đường tròn $(O; 10\\text{ cm})$ có dây cung $AB = 16\\text{ cm}$. Khoảng cách từ tâm $O$ đến dây $AB$ bằng:',
    options: [
      '$6\\text{ cm}$',
      '$8\\text{ cm}$',
      '$4\\text{ cm}$',
      '$\\sqrt{68}\\text{ cm}$'
    ],
    correctAnswer: 0,
    explanation: 'Kẻ $OH \\perp AB \\Rightarrow H$ là trung điểm của $AB \\Rightarrow AH = 8\\text{ cm}$.\nTrong $\\triangle OAH$ vuông tại $H$: $OH = \\sqrt{OA^2 - AH^2} = \\sqrt{10^2 - 8^2} = \\sqrt{36} = 6\\text{ cm}$.',
    difficulty: 'medium',
    points: 15
  },

  // ==========================================
  // CHỦ ĐỀ 6: HÀM SỐ Y = AX² & PHƯƠNG TRÌNH BẬC HAI
  // ==========================================
  {
    id: 'ptb2_01',
    topicId: 'ham_so_bac_hai',
    title: 'Tính đồng biến nghịch biến của Parabol',
    content: 'Hàm số $y = -2x^2$ đồng biến khi:',
    options: [
      '$x < 0$',
      '$x > 0$',
      '$x \\in \\mathbb{R}$',
      '$x \\ne 0$'
    ],
    correctAnswer: 0,
    explanation: 'Với hàm số $y = ax^2$ có hệ số $a = -2 < 0$, hàm số đồng biến khi $x < 0$ và nghịch biến khi $x > 0$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'ptb2_02',
    topicId: 'ham_so_bac_hai',
    title: 'Số nghiệm của phương trình bậc hai theo biệt thức Delta',
    content: 'Phương trình $x^2 - 4x + 4 = 0$ có biệt thức $\\Delta$ và số nghiệm là:',
    options: [
      '$\\Delta = 0$, phương trình có nghiệm kép $x = 2$',
      '$\\Delta > 0$, phương trình có 2 nghiệm phân biệt',
      '$\\Delta < 0$, phương trình vô nghiệm',
      '$\\Delta = 0$, phương trình có nghiệm kép $x = -2$'
    ],
    correctAnswer: 0,
    explanation: '$\\Delta = (-4)^2 - 4 \\cdot 1 \\cdot 4 = 16 - 16 = 0$.\nVì $\\Delta = 0$ nên phương trình có nghiệm kép $x = -\\frac{b}{2a} = -\\frac{-4}{2} = 2$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'ptb2_03',
    topicId: 'ham_so_bac_hai',
    title: 'Giải phương trình bậc hai',
    content: 'Tập nghiệm của phương trình $2x^2 - 5x + 2 = 0$ là:',
    options: [
      '\\{2; 0{,}5\\}',
      '\\{-2; -0{,}5\\}',
      '\\{1; 2\\}',
      '\\{2; -0{,}5\\}'
    ],
    correctAnswer: 0,
    explanation: '$\\Delta = (-5)^2 - 4 \\cdot 2 \\cdot 2 = 25 - 16 = 9 > 0$.\n$x_1 = \\frac{5 + 3}{4} = 2$, $x_2 = \\frac{5 - 3}{4} = 0{,}5$.\nVậy nghiệm là $S = \\{2; 0{,}5\\}$.',
    difficulty: 'medium',
    points: 15
  },

  // ==========================================
  // CHỦ ĐỀ 7: ĐỊNH LÝ VI-ÉT VÀ ỨNG DỤNG
  // ==========================================
  {
    id: 'viet_01',
    topicId: 'he_thuc_viet',
    title: 'Tổng và tích hai nghiệm',
    content: 'Cho phương trình $x^2 - 7x + 10 = 0$. Giá trị của $x_1 + x_2$ và $x_1 \\cdot x_2$ lần lượt là:',
    options: [
      '$S = 7; P = 10$',
      '$S = -7; P = 10$',
      '$S = 7; P = -10$',
      '$S = -7; P = -10$'
    ],
    correctAnswer: 0,
    explanation: 'Theo định lý Vi-ét: $x_1 + x_2 = -\\frac{b}{a} = -\\frac{-7}{1} = 7$; $x_1 x_2 = \\frac{c}{a} = 10$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'viet_02',
    topicId: 'he_thuc_viet',
    title: 'Tính biểu thức đối xứng nghiệm',
    content: 'Gọi $x_1, x_2$ là nghiệm của phương trình $x^2 - 3x - 1 = 0$. Giá trị biểu thức $A = x_1^2 + x_2^2$ là:',
    options: [
      '$11$',
      '$7$',
      '$9$',
      '$10$'
    ],
    correctAnswer: 0,
    explanation: 'Theo Vi-ét: $S = x_1 + x_2 = 3$, $P = x_1 x_2 = -1$.\n$x_1^2 + x_2^2 = (x_1 + x_2)^2 - 2x_1 x_2 = 3^2 - 2(-1) = 9 + 2 = 11$.',
    difficulty: 'medium',
    points: 15
  },
  {
    id: 'viet_03',
    topicId: 'he_thuc_viet',
    title: 'Tìm hai số khi biết tổng và tích',
    content: 'Hai số có tổng $S = 9$ và tích $P = 20$ là nghiệm của phương trình nào?',
    options: [
      '$x^2 - 9x + 20 = 0$',
      '$x^2 + 9x + 20 = 0$',
      '$x^2 - 9x - 20 = 0$',
      '$x^2 - 20x + 9 = 0$'
    ],
    correctAnswer: 0,
    explanation: 'Hai số có tổng là $S$ và tích là $P$ là nghiệm của phương trình $X^2 - SX + P = 0$. Do đó phương trình là $x^2 - 9x + 20 = 0$ (hai số là 4 và 5).',
    difficulty: 'easy',
    points: 10
  },

  // ==========================================
  // CHỦ ĐỀ 8: GÓC VỚI ĐƯỜNG TRÒN & TỨ GIÁC NỘI TIẾP
  // ==========================================
  {
    id: 'goc_01',
    topicId: 'goc_duong_tron',
    title: 'Số đo góc ở tâm và góc nội tiếp',
    content: 'Trong một đường tròn, góc nội tiếp chắn nửa đường tròn có số đo bằng:',
    options: [
      '$90^\\circ$',
      '$60^\\circ$',
      '$180^\\circ$',
      '$45^\\circ$'
    ],
    correctAnswer: 0,
    explanation: 'Góc nội tiếp chắn nửa đường tròn luôn là góc vuông, có số đo bằng $90^\\circ$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'goc_02',
    topicId: 'goc_duong_tron',
    title: 'Dấu hiệu nhận biết tứ giác nội tiếp',
    content: 'Tứ giác $ABCD$ nội tiếp đường tròn khi có một trong các điều kiện sau:',
    options: [
      'Tổng hai góc đối diện bằng $180^\\circ$',
      'Hai cạnh đối song song',
      'Tổng bốn góc bằng $360^\\circ$',
      'Hai đường chéo bằng nhau'
    ],
    correctAnswer: 0,
    explanation: 'Một tứ giác nội tiếp đường tròn khi và chỉ khi tổng số đo hai góc đối diện bằng $180^\\circ$ (hoặc hai đỉnh cùng nhìn một cạnh dưới hai góc bằng nhau).',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'goc_03',
    topicId: 'goc_duong_tron',
    title: 'Mối quan hệ giữa góc ở tâm và góc nội tiếp cùng chắn một cung',
    content: 'Cho đường tròn $(O)$, cung $AmB$ có số đo $80^\\circ$. Góc nội tiếp chắn cung $AmB$ có số đo là:',
    options: [
      '$40^\\circ$',
      '$80^\\circ$',
      '$160^\\circ$',
      '$20^\\circ$'
    ],
    correctAnswer: 0,
    explanation: 'Số đo của góc nội tiếp bằng một nửa số đo của cung bị chắn: $\\frac{80^\\circ}{2} = 40^\\circ$.',
    difficulty: 'easy',
    points: 10
  },

  // ==========================================
  // CHỦ ĐỀ 9: HÌNH TRỤ - HÌNH NÓN - HÌNH CẦU
  // ==========================================
  {
    id: 'hkg_01',
    topicId: 'hinh_khong_gian',
    title: 'Thể tích hình trụ',
    content: 'Một hình trụ có bán kính đáy $r = 3\\text{ cm}$ và chiều cao $h = 5\\text{ cm}$. Thể tích của hình trụ là:',
    options: [
      '$45\\pi\\text{ cm}^3$',
      '$15\\pi\\text{ cm}^3$',
      '$30\\pi\\text{ cm}^3$',
      '$75\\pi\\text{ cm}^3$'
    ],
    correctAnswer: 0,
    explanation: 'Công thức thể tích hình trụ: $V = \\pi r^2 h = \\pi \\cdot 3^2 \\cdot 5 = 45\\pi\\text{ cm}^3$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'hkg_02',
    topicId: 'hinh_khong_gian',
    title: 'Diện tích mặt cầu',
    content: 'Một quả bóng hình cầu có bán kính $R = 10\\text{ cm}$. Diện tích mặt cầu là:',
    options: [
      '$400\\pi\\text{ cm}^2$',
      '$100\\pi\\text{ cm}^2$',
      '$\\frac{4000}{3}\\pi\\text{ cm}^3$',
      '$200\\pi\\text{ cm}^2$'
    ],
    correctAnswer: 0,
    explanation: 'Diện tích mặt cầu tính theo công thức: $S = 4\\pi R^2 = 4 \\cdot \\pi \\cdot 10^2 = 400\\pi\\text{ cm}^2$.',
    difficulty: 'medium',
    points: 15
  },

  // ==========================================
  // CHỦ ĐỀ 10: XÁC SUẤT & THỐNG KÊ 9
  // ==========================================
  {
    id: 'tk_01',
    topicId: 'xac_suat_thong_ke',
    title: 'Xác suất của biến cố ngẫu nhiên',
    content: 'Gieo một con xúc xắc cân đối và đồng chất 6 mặt. Xác suất xuất hiện mặt có số chấm là số nguyên tố bằng:',
    options: [
      '$\\frac{1}{2}$',
      '$\\frac{1}{3}$',
      '$\\frac{2}{3}$',
      '$\\frac{1}{6}$'
    ],
    correctAnswer: 0,
    explanation: 'Các mặt là số nguyên tố: $\\{2; 3; 5\\}$ (gồm 3 mặt). Tổng số mặt là 6.\nXác suất: $P = \\frac{3}{6} = \\frac{1}{2}$.',
    difficulty: 'easy',
    points: 10
  },
  {
    id: 'tk_02',
    topicId: 'xac_suat_thong_ke',
    title: 'Tần số tương đối',
    content: 'Một lớp có 40 học sinh, trong đó có 16 học sinh giỏi. Tần số tương đối của học sinh giỏi trong lớp là:',
    options: [
      '$40\\%$',
      '$16\\%$',
      '$25\\%$',
      '$60\\%$'
    ],
    correctAnswer: 0,
    explanation: 'Tần số tương đối $f = \\frac{16}{40} \\cdot 100\\% = 40\\%$.',
    difficulty: 'easy',
    points: 10
  }
];

// DỮ LIỆU ĐỀ THI HỌC KỲ I (CHÍNH THỨC TRƯỜNG THCS NGHĨA AN 2025-2026)
const REAL_EXAMS = [
  {
    id: 'exam_na_101',
    title: 'Đề Kiểm Tra Học Kỳ I - Mã Đề 101 (THCS Nghĩa An)',
    school: 'THCS Nghĩa An - Nghệ An (Năm học 2025 - 2026)',
    duration: 90, // phút
    totalQuestions: 12,
    sections: [
      {
        name: 'Phần I: Trắc nghiệm lựa chọn (2,5 điểm)',
        questions: [
          {
            id: 'na101_q1',
            number: 1,
            content: 'Điều kiện xác định của biểu thức $\\sqrt{2x - 4}$ là:',
            options: ['$x \\ge 2$', '$x > 2$', '$x \\le 2$', '$x < 2$'],
            correctAnswer: 0,
            explanation: '$2x - 4 \\ge 0 \\Leftrightarrow 2x \\ge 4 \\Leftrightarrow x \\ge 2$.'
          },
          {
            id: 'na101_q2',
            number: 2,
            content: 'Trong tam giác vuông, $\\cos B$ bằng tỉ số giữa:',
            options: [
              'Cạnh kề và cạnh huyền',
              'Cạnh đối và cạnh huyền',
              'Cạnh đối và cạnh kề',
              'Cạnh kề và cạnh đối'
            ],
            correctAnswer: 0,
            explanation: 'Theo định nghĩa lượng giác: Cosin của góc nhọn bằng cạnh kề chia cho cạnh huyền.'
          },
          {
            id: 'na101_q3',
            number: 3,
            content: 'Trong các đẳng thức sau, hệ thức nào KHÔNG PHẢI là phương trình bậc nhất hai ẩn?',
            options: [
              '$0x - 0y = 4$',
              '$-3x + 3y = 3$',
              '$0x - 2y = 0$',
              '$3x + 0y = 1$'
            ],
            correctAnswer: 0,
            explanation: 'Phương trình bậc nhất hai ẩn $ax + by = c$ yêu cầu $a$ và $b$ không đồng thời bằng 0.'
          },
          {
            id: 'na101_q4',
            number: 4,
            content: 'Cho hai đường tròn $(O; 4\\text{ cm})$ và $(O\'; 2\\text{ cm})$. Biết $OO\' = 6\\text{ cm}$ thì hai đường tròn trên:',
            options: [
              'Cắt nhau',
              'Tiếp xúc ngoài',
              'Tiếp xúc trong',
              'Không giao nhau'
            ],
            correctAnswer: 1,
            explanation: 'Do $OO\' = R_1 + R_2 = 4 + 2 = 6\\text{ cm}$, hai đường tròn tiếp xúc ngoài.'
          },
          {
            id: 'na101_q5',
            number: 5,
            content: 'Đường thẳng $AB$ là tiếp tuyến của đường tròn $(O)$ tại $B$, khi đó:',
            options: [
              '$AB$ không cắt $(O)$',
              '$AB \\perp OB$',
              '$AB$ đi qua điểm $O$',
              '$AB$ cắt $(O)$ tại 2 điểm'
            ],
            correctAnswer: 1,
            explanation: 'Tiếp tuyến của đường tròn luôn vuông góc với bán kính tại tiếp điểm: $AB \\perp OB$.'
          },
          {
            id: 'na101_q6',
            number: 6,
            content: 'Hệ phương trình $\\begin{cases} x + y = 3 \\\\ x - y = 1 \\end{cases}$ có nghiệm là:',
            options: [
              '$(1; 2)$',
              '$(2; 1)$',
              '$(3; 0)$',
              '$(0; 3)$'
            ],
            correctAnswer: 1,
            explanation: 'Cộng 2 phương trình: $2x = 4 \\Rightarrow x = 2$; thay vào: $y = 1$.'
          },
          {
            id: 'na101_q7',
            number: 7,
            content: 'Kết quả rút gọn của biểu thức $\\sqrt{(3 - \\sqrt{10})^2}$ là:',
            options: [
              '$3 - \\sqrt{10}$',
              '$\\sqrt{10} + 3$',
              '$\\sqrt{10} - 3$',
              '$-3 - \\sqrt{10}$'
            ],
            correctAnswer: 2,
            explanation: 'Vì $3 < \\sqrt{10}$ nên $\\sqrt{(3-\\sqrt{10})^2} = |3-\\sqrt{10}| = \\sqrt{10} - 3$.'
          },
          {
            id: 'na101_q8',
            number: 8,
            content: 'Kết quả của phép tính $\\sqrt{16} \\cdot \\sqrt{25} - \\sqrt{100}$ bằng:',
            options: [
              '$10$',
              '$20$',
              '$50$',
              '$4$'
            ],
            correctAnswer: 0,
            explanation: '$4 \\cdot 5 - 10 = 20 - 10 = 10$.'
          },
          {
            id: 'na101_q9',
            number: 9,
            content: 'Một máy bay cất cánh bay lên quãng đường $10\\text{ km}$, góc tạo với mặt đất $20^\\circ$. Độ cao máy bay đạt được xấp xỉ là:',
            options: [
              '$3{,}5\\text{ km}$',
              '$3{,}3\\text{ km}$',
              '$3{,}4\\text{ km}$',
              '$3{,}2\\text{ km}$'
            ],
            correctAnswer: 2,
            explanation: '$h = 10 \\cdot \\sin 20^\\circ \\approx 3{,}4\\text{ km}$.'
          },
          {
            id: 'na101_q10',
            number: 10,
            content: 'Lúc 2 giờ đúng, góc ở tâm tạo bởi kim giờ và kim phút của đồng hồ có số đo là:',
            options: [
              '$60^\\circ$',
              '$120^\\circ$',
              '$150^\\circ$',
              '$30^\\circ$'
            ],
            correctAnswer: 0,
            explanation: 'Mỗi khoảng giờ tương ứng với $360^\\circ / 12 = 30^\\circ$. Lúc 2 giờ hai kim cách nhau 2 khoảng nên góc là $2 \\times 30^\\circ = 60^\\circ$.'
          }
        ]
      },
      {
        name: 'Phần II: Đúng / Sai (1,0 điểm)',
        type: 'true_false',
        content: 'Cho biểu thức $A = \\left(\\frac{1}{\\sqrt{x}-1} + \\frac{1}{\\sqrt{x}+1}\\right) : \\frac{2}{x-1}$ với $x \\ge 0, x \\ne 1$:',
        subQuestions: [
          { label: 'a)', text: 'Điều kiện xác định của biểu thức A là $x \\ge 0, x \\ne 1$.', isCorrect: true, explain: 'Đúng theo đề bài.' },
          { label: 'b)', text: 'Kết quả rút gọn của biểu thức A là $\\sqrt{x}$.', isCorrect: true, explain: 'Quy đồng tử số: $\\frac{2\\sqrt{x}}{x-1} \\cdot \\frac{x-1}{2} = \\sqrt{x}$.' },
          { label: 'c)', text: 'Giá trị của biểu thức A khi $x = 9$ là 11.', isCorrect: false, explain: 'Sai. Khi $x = 9$, $A = \\sqrt{9} = 3 \\ne 11$.' },
          { label: 'd)', text: 'Giá trị $x$ để biểu thức A có giá trị bằng 2 là $x = 4$.', isCorrect: true, explain: 'Đúng. $A = 2 \\Leftrightarrow \\sqrt{x} = 2 \\Leftrightarrow x = 4$.' }
        ]
      },
      {
        name: 'Phần III: Tự luận & Lời giải mẫu',
        type: 'essay',
        essayQuestions: [
          {
            number: 'Bài 1',
            score: '2,5 điểm',
            text: 'a) Tính $\\sqrt{50} - \\sqrt{18} + \\sqrt{8}$\nb) Rút gọn biểu thức $P = \\frac{x - 4}{\\sqrt{x} + 2}$ với $x \\ge 0$\nc) Giải bất phương trình: $2x - 3 \\le 5x + 6$',
            solution: 'a) $\\sqrt{50} - \\sqrt{18} + \\sqrt{8} = 5\\sqrt{2} - 3\\sqrt{2} + 2\\sqrt{2} = 4\\sqrt{2}$.\nb) $P = \\frac{(\\sqrt{x}-2)(\\sqrt{x}+2)}{\\sqrt{x}+2} = \\sqrt{x} - 2$.\nc) $2x - 5x \\le 6 + 3 \\Leftrightarrow -3x \\le 9 \\Leftrightarrow x \\ge -3$.'
          },
          {
            number: 'Bài 2',
            score: '1,0 điểm',
            text: 'Hai lớp 9A và 9B quyên góp sách giáo khoa cũ ủng hộ vùng lũ năm 2025 được 250 cuốn. Biết rằng lớp 9A ủng hộ nhiều hơn lớp 9B là 30 cuốn. Hỏi mỗi lớp đã ủng hộ được bao nhiêu cuốn?',
            solution: 'Gọi số sách lớp 9A và 9B lần lượt là $x, y$ ($x, y \\in \\mathbb{N}^*$).\nTheo bài ra ta có hệ phương trình:\n$$\\begin{cases} x + y = 250 \\\\ x - y = 30 \\end{cases}$$\nCộng 2 phương trình: $2x = 280 \\Rightarrow x = 140$.\nThay vào: $y = 250 - 140 = 110$.\nVậy lớp 9A ủng hộ 140 cuốn, lớp 9B ủng hộ 110 cuốn.'
          },
          {
            number: 'Bài 4',
            score: '0,5 điểm',
            text: 'Bài toán tối ưu chi phí (Bất đẳng thức AM-GM trong thực tế sản xuất): Tìm số máy móc tối ưu để chi phí sản xuất thấp nhất.',
            solution: 'Áp dụng BĐT AM-GM: Chi phí $C(x) = ax + \\frac{b}{x} \\ge 2\\sqrt{ab}$. Dấu bằng xảy ra khi $ax = \\frac{b}{x} \\Leftrightarrow x = \\sqrt{\\frac{b}{a}}$.'
          }
        ]
      }
    ]
  }
];

// DỮ LIỆU CÁC TẦNG LEO THÁP (TOWER CLIMB / BOSS BATTLE)
const TOWER_FLOORS = [
  {
    floor: 1,
    name: 'Tầng 1: Đồng Cỏ Khởi Nguyên',
    boss: 'Slime Tính Nhẩm',
    bossAvatar: '🟢',
    bossHp: 100,
    topic: 'Tính nhẩm & Căn số học cơ bản',
    bgGradient: 'from-emerald-900 to-teal-950',
    dialogue: 'Ngươi muốn leo tháp ư? Hãy vượt qua phép thử tính nhanh của ta trước đã!',
    rewardExp: 50,
    questions: ['ct_01', 'ct_03', 'tk_01']
  },
  {
    floor: 2,
    name: 'Tầng 2: Rừng Căn Thức Bí Ẩn',
    boss: 'Yêu Tinh Căn Bậc Hai',
    bossAvatar: '🧌',
    bossHp: 150,
    topic: 'Hằng đẳng thức & Rút gọn căn thức',
    bgGradient: 'from-amber-900 to-yellow-950',
    dialogue: 'Căn thức của ta có hai lớp bảo vệ! Ngươi có biết giải trị tuyệt đối không?',
    rewardExp: 80,
    questions: ['ct_02', 'ct_04', 'ct_06']
  },
  {
    floor: 3,
    name: 'Tầng 3: Mê Cung Ẩn Số',
    boss: 'Phù Thủy Hệ Phương Trình',
    bossAvatar: '🧙‍♂️',
    bossHp: 200,
    topic: 'Giải hệ hai phương trình bậc nhất',
    bgGradient: 'from-blue-900 to-indigo-950',
    dialogue: 'Phương pháp thế hay cộng đại số? Liệu ngươi có tìm ra x và y?',
    rewardExp: 110,
    questions: ['hpt_01', 'hpt_02', 'hpt_03']
  },
  {
    floor: 4,
    name: 'Tầng 4: Đỉnh Núi Lượng Giác',
    boss: 'Thần Điêu Sin Cos Tan',
    bossAvatar: '🦅',
    bossHp: 250,
    topic: 'Tỉ số lượng giác góc nhọn',
    bgGradient: 'from-cyan-900 to-sky-950',
    dialogue: 'Sao đối chia kề, huyền kề sin cos... Ngươi đã thuộc lòng hết chưa?',
    rewardExp: 150,
    questions: ['htl_01', 'htl_02', 'htl_03', 'htl_04']
  },
  {
    floor: 5,
    name: 'Tầng 5: Pháo Đài Tiếp Tuyến',
    boss: 'Hiệp Sĩ Đường Tròn',
    bossAvatar: '🛡️',
    bossHp: 300,
    topic: 'Đường tròn và tiếp tuyến cắt nhau',
    bgGradient: 'from-rose-900 to-red-950',
    dialogue: 'Khiên của ta tròn hoàn hảo! Bán kính và tiếp tuyến luôn vuông góc!',
    rewardExp: 200,
    questions: ['dt_01', 'dt_02', 'dt_03', 'dt_04']
  },
  {
    floor: 6,
    name: 'Tầng 6: Vực Thẳm Bất Đẳng Thức',
    boss: 'Ma Vương Cauchy AM-GM',
    bossAvatar: '👹',
    bossHp: 350,
    topic: 'Bất phương trình và cực trị',
    bgGradient: 'from-teal-900 to-slate-950',
    dialogue: 'A cộng B lớn hơn hai lần căn AB! Hãy đón nhận cực trị của ta!',
    rewardExp: 260,
    questions: ['bpt_01', 'bpt_02', 'bpt_03', 'hpt_04']
  },
  {
    floor: 7,
    name: 'Tầng 7: Thung Lũng Parabol',
    boss: 'Quái Thú Đồ Thị y = ax²',
    bossAvatar: '🐲',
    bossHp: 400,
    topic: 'Hàm số bậc hai và biệt thức Delta',
    bgGradient: 'from-purple-900 to-fuchsia-950',
    dialogue: 'Parabol của ta có thể quay bề lõm lên hoặc xuống! Ngươi né được không?',
    rewardExp: 330,
    questions: ['ptb2_01', 'ptb2_02', 'ptb2_03']
  },
  {
    floor: 8,
    name: 'Tầng 8: Điện Thờ Vi-ét Thần Thánh',
    boss: 'Đại Pháp Sư Vi-ét',
    bossAvatar: '⚡',
    bossHp: 450,
    topic: 'Tổng và tích hai nghiệm x₁ + x₂, x₁x₂',
    bgGradient: 'from-violet-900 to-indigo-950',
    dialogue: 'Không cần giải phương trình, ta vẫn biết tổng và tích nghiệm!',
    rewardExp: 420,
    questions: ['viet_01', 'viet_02', 'viet_03']
  },
  {
    floor: 9,
    name: 'Tầng 9: Đảo Tứ Giác Nội Tiếp',
    boss: 'Hải Long Vương Cung Tròn',
    bossAvatar: '🐉',
    bossHp: 500,
    topic: 'Góc với đường tròn & Tứ giác nội tiếp',
    bgGradient: 'from-blue-950 to-slate-900',
    dialogue: 'Bốn đỉnh cùng nằm trên một đường tròn! Hãy tìm góc bù 180 độ!',
    rewardExp: 520,
    questions: ['goc_01', 'goc_02', 'goc_03', 'hkg_01']
  },
  {
    floor: 10,
    name: 'Tầng 10: ĐỈNH THÁP HUYỀN THOẠI',
    boss: 'Chiến Thần Toán Học Lớp 10',
    bossAvatar: '👑',
    bossHp: 650,
    topic: 'Đề thi tổng hợp Tuyển Sinh Vào 10',
    bgGradient: 'from-amber-700 via-rose-900 to-purple-950',
    dialogue: 'Ngươi đã đi đến đích! Hãy chứng minh ngươi xứng đáng đỗ Thủ Khoa!',
    rewardExp: 1000,
    questions: ['ct_05', 'hpt_05', 'bpt_03', 'htl_04', 'viet_02', 'hkg_02']
  }
];

// SỔ TAY CÔNG THỨC TOÁN 9 (BÍ KÍP ÔN THI CẤP TỐC)
const FORMULA_BOOK = [
  {
    category: 'Đại số: Căn bậc hai',
    icon: '√',
    items: [
      {
        title: 'Điều kiện xác định căn thức',
        formula: '$\\sqrt{A}$ có nghĩa $\\Leftrightarrow A \\ge 0$',
        note: 'Chú ý biểu thức dưới mẫu phải khác 0.'
      },
      {
        title: 'Hằng đẳng thức căn bậc hai',
        formula: '$\\sqrt{A^2} = |A| = \\begin{cases} A & \\text{khi } A \\ge 0 \\\\ -A & \\text{khi } A < 0 \\end{cases}$',
        note: 'Luôn mở dấu giá trị tuyệt đối trước khi tính tiếp.'
      },
      {
        title: 'Khai phương tích & thương',
        formula: '$\\sqrt{A \\cdot B} = \\sqrt{A} \\cdot \\sqrt{B}$ ($A, B \\ge 0$)\n$\\sqrt{\\frac{A}{B}} = \\frac{\\sqrt{A}}{\\sqrt{B}}$ ($A \\ge 0, B > 0$)',
        note: 'Đưa thừa số ra ngoài/vào trong dấu căn: $\\sqrt{A^2 B} = |A|\\sqrt{B}$.'
      },
      {
        title: 'Trục căn thức ở mẫu (Lượng liên hợp)',
        formula: '$\\frac{C}{\\sqrt{A} \\pm \\sqrt{B}} = \\frac{C(\\sqrt{A} \\mp \\sqrt{B})}{A - B}$',
        note: 'Nhớ đổi dấu: nhân với lượng liên hợp tương ứng.'
      }
    ]
  },
  {
    category: 'Đại số: Hệ phương trình bậc nhất 2 ẩn',
    icon: '{ }',
    items: [
      {
        title: 'Quy tắc giải hệ PT',
        formula: '1. Phương pháp Thế (rút ẩn này theo ẩn kia)\n2. Phương pháp Cộng đại số (nhân hệ số bằng nhau hoặc đối nhau)',
        note: 'Nên kiểm tra lại nghiệm bằng cách thay vào cả hai phương trình.'
      },
      {
        title: 'Điều kiện nghiệm của hệ',
        formula: '$\\begin{cases} a_1 x + b_1 y = c_1 \\\\ a_2 x + b_2 y = c_2 \\end{cases}$\n- Nghiệm duy nhất: $\\frac{a_1}{a_2} \\ne \\frac{b_1}{b_2}$\n- Vô nghiệm: $\\frac{a_1}{a_2} = \\frac{b_1}{b_2} \\ne \\frac{c_1}{c_2}$\n- Vô số nghiệm: $\\frac{a_1}{a_2} = \\frac{b_1}{b_2} = \\frac{c_1}{c_2}$',
        note: 'Chỉ áp dụng khi các hệ số ở mẫu khác 0.'
      }
    ]
  },
  {
    category: 'Đại số: Phương trình bậc hai & Vi-ét',
    icon: 'x²',
    items: [
      {
        title: 'Công thức nghiệm PT bậc hai',
        formula: '$ax^2 + bx + c = 0$ ($a \\ne 0$)\n$\\Delta = b^2 - 4ac$\n- $\\Delta > 0$: 2 nghiệm PB $x_{1,2} = \\frac{-b \\pm \\sqrt{\\Delta}}{2a}$\n- $\\Delta = 0$: Nghiệm kép $x_1 = x_2 = -\\frac{b}{2a}$\n- $\\Delta < 0$: Phương trình vô nghiệm',
        note: 'Nếu $b = 2b\'$ thì dùng $\\Delta\' = (b\')^2 - ac$.'
      },
      {
        title: 'Định lý Vi-ét',
        formula: 'Nếu PT có nghiệm thì:\n$$x_1 + x_2 = -\\frac{b}{a}$$\n$$x_1 \\cdot x_2 = \\frac{c}{a}$$',
        note: 'Tổng $S = x_1 + x_2$, Tích $P = x_1 x_2$. Nhẩm nghiệm: $a+b+c=0 \\Rightarrow x_1=1, x_2=\\frac{c}{a}$.'
      },
      {
        title: 'Các biểu thức đối xứng quen thuộc',
        formula: '- $x_1^2 + x_2^2 = S^2 - 2P$\n- $(x_1 - x_2)^2 = S^2 - 4P$\n- $\\frac{1}{x_1} + \\frac{1}{x_2} = \\frac{S}{P}$\n- $x_1^3 + x_2^3 = S^3 - 3SP$',
        note: 'Dạng bài rất hay xuất hiện trong đề thi vào 10!'
      }
    ]
  },
  {
    category: 'Hình học: Hệ thức lượng trong tam giác vuông',
    icon: '📐',
    items: [
      {
        title: 'Các hệ thức về cạnh và đường cao',
        formula: 'Cho $\\triangle ABC$ vuông tại $A$, đường cao $AH$:\n1. $b^2 = a \\cdot b\'$; $c^2 = a \\cdot c\'$\n2. $h^2 = b\' \\cdot c\'$\n3. $b \\cdot c = a \\cdot h$\n4. $\\frac{1}{h^2} = \\frac{1}{b^2} + \\frac{1}{c^2}$\n5. $a^2 = b^2 + c^2$ (Py-ta-go)',
        note: 'Trong đó $a=BC, b=AC, c=AB, h=AH, b\'=CH, c\'=BH$.'
      },
      {
        title: 'Tỉ số lượng giác góc nhọn',
        formula: '$$\\sin = \\frac{\\text{đối}}{\\text{huyền}}; \\quad \\cos = \\frac{\\text{kề}}{\\text{huyền}}$$\n$$\\tan = \\frac{\\text{đối}}{\\text{kề}}; \\quad \\cot = \\frac{\\text{kề}}{\\text{đối}}$$',
        note: 'Câu ghi nhớ: "Sao đi học, cứ khóc hoài, thôi đừng khóc, có kẹo đây".'
      }
    ]
  },
  {
    category: 'Hình học: Đường tròn & Góc',
    icon: '⭕',
    items: [
      {
        title: 'Góc với đường tròn',
        formula: '- Góc ở tâm: Sđ góc = Sđ cung bị chắn\n- Góc nội tiếp: Sđ góc = $\\frac{1}{2}$ Sđ cung bị chắn\n- Góc tạo bởi tiếp tuyến & dây cung: Sđ góc = $\\frac{1}{2}$ Sđ cung bị chắn',
        note: 'Góc nội tiếp chắn nửa đường tròn luôn bằng $90^\\circ$.'
      },
      {
        title: 'Dấu hiệu nhận biết Tứ giác nội tiếp',
        formula: '1. Tứ giác có tổng hai góc đối diện bằng $180^\\circ$.\n2. Tứ giác có góc ngoài tại một đỉnh bằng góc trong tại đỉnh đối diện.\n3. Tứ giác có hai đỉnh kề cùng nhìn cạnh chứa hai đỉnh còn lại dưới các góc bằng nhau.\n4. Bốn đỉnh cách đều một điểm cố định.',
        note: 'Đây là câu phân loại điểm 8, 9, 10 trong mọi đề thi vào 10!'
      }
    ]
  },
  {
    category: 'Hình học: Thể tích & Diện tích hình khối',
    icon: '🧊',
    items: [
      {
        title: 'Hình trụ, Hình nón, Hình cầu',
        formula: '- Hình trụ: $S_{xq} = 2\\pi rh$; $V = \\pi r^2 h$\n- Hình nón: $S_{xq} = \\pi rl$; $V = \\frac{1}{3}\\pi r^2 h$ ($l^2 = r^2 + h^2$)\n- Hình cầu: $S = 4\\pi R^2$; $V = \\frac{4}{3}\\pi R^3$',
        note: '$r$ là bán kính đáy, $h$ là chiều cao, $l$ là đường sinh.'
      }
    ]
  }
];

// DANH SÁCH HUY HIỆU (ACHIEVEMENTS)
const ACHIEVEMENTS = [
  { id: 'first_win', name: 'Phát Súng Đầu Tiên', desc: 'Trả lời đúng câu hỏi đầu tiên', icon: '🎯', exp: 20 },
  { id: 'combo_5', name: 'Chuỗi Cao Thủ', desc: 'Đạt chuỗi 5 câu đúng liên tiếp', icon: '⚡', exp: 50 },
  { id: 'combo_10', name: 'Thánh Tính Nhẩm', desc: 'Đạt chuỗi 10 câu đúng liên tiếp', icon: '🔥', exp: 120 },
  { id: 'floor_3', name: 'Người Leo Tháp', desc: 'Vượt qua Tầng 3 Tháp Tri Thức', icon: '🧗', exp: 100 },
  { id: 'floor_7', name: 'Chiến Binh Đại Số', desc: 'Vượt qua Tầng 7 Tháp Tri Thức', icon: '⚔️', exp: 200 },
  { id: 'tower_master', name: 'Chúa Tể Tháp Toán 9', desc: 'Vượt qua toàn bộ 10 tầng tháp', icon: '👑', exp: 500 },
  { id: 'speed_master', name: 'Tia Chớp 60 Giây', desc: 'Đạt trên 150 điểm trong Thử Thách Tốc Độ', icon: '⏱️', exp: 150 },
  { id: 'exam_passed', name: 'Sĩ Tử Xuất Sắc', desc: 'Hoàn thành bài thi thử đạt trên 8 điểm', icon: '📜', exp: 200 },
  { id: 'pvp_winner', name: 'Vua Đấu Trường 1v1', desc: 'Chiến thắng 1 trận đấu Song Đấu 1v1', icon: '🏆', exp: 100 }
];

// DANH HIỆU & AVATAR CÓ THỂ MỞ KHÓA
const AVATARS = [
  { id: 'av_1', icon: '🐱', name: 'Mèo Học Toán', unlockLevel: 1 },
  { id: 'av_2', icon: '🐶', name: 'Cún Chăm Chỉ', unlockLevel: 2 },
  { id: 'av_3', icon: '🦊', name: 'Cáo Thông Thái', unlockLevel: 4 },
  { id: 'av_4', icon: '🦉', name: 'Cú Đêm Ôn Thi', unlockLevel: 7 },
  { id: 'av_5', icon: '🐯', name: 'Hổ Dũng Mãnh', unlockLevel: 10 },
  { id: 'av_6', icon: '🐲', name: 'Rồng Tri Thức', unlockLevel: 15 },
  { id: 'av_7', icon: '🧙‍♂️', name: 'Phù Thủy Số Học', unlockLevel: 20 },
  { id: 'av_8', icon: '👑', name: 'Chiến Thần Toán 9', unlockLevel: 25 }
];
