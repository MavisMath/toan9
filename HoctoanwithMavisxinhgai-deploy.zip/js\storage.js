// ================================================================
// QUẢN LÝ TIẾN ĐỘ, LEVEL, HUY HIỆU VÀ DỮ LIỆU CỤC BỘ (LOCALSTORAGE)
// ================================================================

class StorageManager {
  constructor() {
    this.STORAGE_KEY = 'math9_player_data';
    this.CUSTOM_Q_KEY = 'math9_custom_questions';
    this.LEADERBOARD_KEY = 'math9_leaderboard';
    this.profile = this.loadProfile();
  }

  // Khởi tạo hồ sơ mặc định nếu chưa có
  getDefaultProfile() {
    return {
      name: 'Chiến Binh Toán 9',
      avatar: '🐱',
      level: 1,
      exp: 0,
      expToNextLevel: 100,
      diamonds: 50,
      streak: 0,
      maxStreak: 0,
      highestFloor: 1,
      unlockedAvatars: ['av_1'],
      unlockedAchievements: [],
      answeredQuestions: {}, // { [qId]: { correct: count, wrong: count } }
      topicProgress: {}, // { [topicId]: { correct: 0, total: 0 } }
      speedHighScore: 0,
      lastPlayedDate: null
    };
  }

  loadProfile() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      if (data) {
        return { ...this.getDefaultProfile(), ...JSON.parse(data) };
      }
    } catch (e) {
      console.error('Lỗi đọc dữ liệu hồ sơ:', e);
    }
    return this.getDefaultProfile();
  }

  saveProfile() {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.profile));
    } catch (e) {
      console.error('Lỗi lưu hồ sơ:', e);
    }
  }

  // Thêm EXP và xử lý lên cấp
  addExp(amount, onLevelUp) {
    this.profile.exp += amount;
    let leveledUp = false;

    // Công thức tính EXP cấp tiếp theo: 100 * (level ^ 1.25)
    let needed = Math.floor(100 * Math.pow(this.profile.level, 1.25));
    while (this.profile.exp >= needed) {
      this.profile.exp -= needed;
      this.profile.level++;
      leveledUp = true;
      needed = Math.floor(100 * Math.pow(this.profile.level, 1.25));

      // Mở khóa avatar theo cấp
      if (typeof AVATARS !== 'undefined') {
        AVATARS.forEach(av => {
          if (this.profile.level >= av.unlockLevel && !this.profile.unlockedAvatars.includes(av.id)) {
            this.profile.unlockedAvatars.push(av.id);
          }
        });
      }
    }

    this.profile.expToNextLevel = needed;
    this.saveProfile();

    if (leveledUp && typeof onLevelUp === 'function') {
      onLevelUp(this.profile.level);
    }
    return leveledUp;
  }

  // Ghi nhận câu trả lời
  recordAnswer(qId, topicId, isCorrect) {
    if (!this.profile.answeredQuestions[qId]) {
      this.profile.answeredQuestions[qId] = { correct: 0, wrong: 0 };
    }
    if (isCorrect) {
      this.profile.answeredQuestions[qId].correct++;
      this.profile.streak++;
      if (this.profile.streak > this.profile.maxStreak) {
        this.profile.maxStreak = this.profile.streak;
      }
    } else {
      this.profile.answeredQuestions[qId].wrong++;
      this.profile.streak = 0;
    }

    // Ghi nhận theo chuyên đề
    if (topicId) {
      if (!this.profile.topicProgress[topicId]) {
        this.profile.topicProgress[topicId] = { correct: 0, total: 0 };
      }
      this.profile.topicProgress[topicId].total++;
      if (isCorrect) {
        this.profile.topicProgress[topicId].correct++;
      }
    }

    this.saveProfile();
  }

  // Mở khóa tầng tháp tiếp theo
  unlockNextFloor(floor) {
    if (floor >= this.profile.highestFloor && floor < 10) {
      this.profile.highestFloor = floor + 1;
      this.saveProfile();
    }
  }

  // Kiểm tra và mở khóa huy hiệu
  checkAchievements(onUnlock) {
    if (typeof ACHIEVEMENTS === 'undefined') return [];
    const newlyUnlocked = [];

    ACHIEVEMENTS.forEach(ach => {
      if (this.profile.unlockedAchievements.includes(ach.id)) return;

      let unlock = false;
      if (ach.id === 'first_win') {
        const totalCorrect = Object.values(this.profile.answeredQuestions).reduce((s, q) => s + (q.correct > 0 ? 1 : 0), 0);
        if (totalCorrect >= 1) unlock = true;
      } else if (ach.id === 'combo_5' && this.profile.maxStreak >= 5) {
        unlock = true;
      } else if (ach.id === 'combo_10' && this.profile.maxStreak >= 10) {
        unlock = true;
      } else if (ach.id === 'floor_3' && this.profile.highestFloor >= 4) {
        unlock = true;
      } else if (ach.id === 'floor_7' && this.profile.highestFloor >= 8) {
        unlock = true;
      } else if (ach.id === 'tower_master' && this.profile.highestFloor >= 10) {
        unlock = true;
      } else if (ach.id === 'speed_master' && this.profile.speedHighScore >= 150) {
        unlock = true;
      }

      if (unlock) {
        this.profile.unlockedAchievements.push(ach.id);
        this.addExp(ach.exp);
        newlyUnlocked.push(ach);
        if (typeof onUnlock === 'function') onUnlock(ach);
      }
    });

    if (newlyUnlocked.length > 0) {
      this.saveProfile();
    }
    return newlyUnlocked;
  }

  // Lấy câu hỏi do giáo viên thêm vào
  getCustomQuestions() {
    try {
      const data = localStorage.getItem(this.CUSTOM_Q_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  // Thêm câu hỏi mới của giáo viên
  addCustomQuestion(question) {
    const questions = this.getCustomQuestions();
    questions.push({
      ...question,
      id: 'custom_' + Date.now(),
      isCustom: true
    });
    localStorage.setItem(this.CUSTOM_Q_KEY, JSON.stringify(questions));
    return questions;
  }

  // Xóa câu hỏi tùy chỉnh
  deleteCustomQuestion(id) {
    const questions = this.getCustomQuestions().filter(q => q.id !== id);
    localStorage.setItem(this.CUSTOM_Q_KEY, JSON.stringify(questions));
    return questions;
  }

  // Cập nhật điểm kỉ lục thử thách tốc độ
  updateSpeedScore(score) {
    if (score > (this.profile.speedHighScore || 0)) {
      this.profile.speedHighScore = score;
      this.saveProfile();
      return true;
    }
    return false;
  }

  // Lấy tất cả câu hỏi (bao gồm cả mặc định + câu hỏi của thầy/cô)
  getAllQuestions() {
    const defaultQs = typeof QUESTIONS !== 'undefined' ? QUESTIONS : [];
    const customQs = this.getCustomQuestions();
    return [...defaultQs, ...customQs];
  }

  // Bảng xếp hạng cục bộ
  getLeaderboard() {
    try {
      const data = localStorage.getItem(this.LEADERBOARD_KEY);
      if (data) return JSON.parse(data);
    } catch (e) {}
    // Mặc định tạo một số kỷ lục mẫu giả lập lớp học
    return [
      { name: 'Nguyễn Văn Minh (Lớp 9A)', avatar: '👑', score: 980, level: 22, streak: 14 },
      { name: 'Trần Thu Hà (Lớp 9B)', avatar: '🦉', score: 860, level: 19, streak: 12 },
      { name: 'Lê Hoàng Nam (Lớp 9A)', avatar: '🐯', score: 720, level: 16, streak: 9 },
      { name: 'Phạm Ngọc Ánh (Lớp 9C)', avatar: '🦊', score: 650, level: 14, streak: 8 },
      { name: 'Đặng Tuấn Anh (Lớp 9B)', avatar: '🐱', score: 510, level: 11, streak: 6 }
    ];
  }

  addLeaderboardRecord(name, score, level) {
    const list = this.getLeaderboard();
    list.push({
      name: name || this.profile.name,
      avatar: this.profile.avatar,
      score: score,
      level: level || this.profile.level,
      date: new Date().toLocaleDateString('vi-VN')
    });
    list.sort((a, b) => b.score - a.score);
    const top10 = list.slice(0, 15);
    localStorage.setItem(this.LEADERBOARD_KEY, JSON.stringify(top10));
    return top10;
  }

  // Reset tiến trình
  resetAll() {
    localStorage.removeItem(this.STORAGE_KEY);
    this.profile = this.getDefaultProfile();
    this.saveProfile();
  }
}

const storage = new StorageManager();
