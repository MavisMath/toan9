// ================================================================
// QUẢN LÝ GIAO DIỆN CHÍNH, TABS VÀ CÁC CHỨC NĂNG HỖ TRỢ
// ================================================================

class AppController {
  constructor() {
    this.currentTab = 'home';
    this.activeTopic = null;
    this.activeTopicQuestions = [];
    this.topicQuestionIndex = 0;
  }

  init() {
    this.updateHeaderStats();
    this.showTab('home');
    this.initAudioToggle();

    // Lắng nghe sự kiện click toàn cục để khởi động AudioContext
    document.addEventListener('click', () => {
      audio.init();
    }, { once: true });
  }

  // Cập nhật thông tin người chơi trên thanh Topbar
  updateHeaderStats() {
    const p = storage.profile;
    const nameEl = document.getElementById('player-name');
    const avatarEl = document.getElementById('player-avatar');
    const levelEl = document.getElementById('player-level');
    const expTextEl = document.getElementById('player-exp-text');
    const expBarEl = document.getElementById('player-exp-bar');
    const diamondsEl = document.getElementById('player-diamonds');
    const streakEl = document.getElementById('player-streak');

    if (nameEl) nameEl.innerText = p.name;
    if (avatarEl) avatarEl.innerText = p.avatar;
    if (levelEl) levelEl.innerText = `Lv.${p.level}`;
    if (diamondsEl) diamondsEl.innerText = p.diamonds || 50;
    if (streakEl) streakEl.innerText = p.streak || 0;

    const needed = p.expToNextLevel || 100;
    const percent = Math.min(100, Math.floor((p.exp / needed) * 100));
    if (expTextEl) expTextEl.innerText = `${p.exp}/${needed} EXP (${percent}%)`;
    if (expBarEl) expBarEl.style.width = `${percent}%`;
  }

  // Chuyển đổi giữa các tab
  showTab(tabName) {
    this.currentTab = tabName;
    audio.playClick();

    // Ẩn tất cả các view
    const views = document.querySelectorAll('.tab-view');
    views.forEach(v => v.classList.add('hidden'));

    // Bỏ active trên thanh điều hướng
    const navBtns = document.querySelectorAll('.nav-tab-btn');
    navBtns.forEach(btn => {
      btn.classList.remove('bg-blue-600', 'text-white', 'shadow-lg');
      btn.classList.add('text-slate-400', 'hover:text-white', 'hover:bg-slate-800');
    });

    // Kích hoạt tab được chọn
    const activeView = document.getElementById(`view-${tabName}`);
    if (activeView) activeView.classList.remove('hidden');

    const activeNavBtn = document.getElementById(`nav-${tabName}`);
    if (activeNavBtn) {
      activeNavBtn.classList.add('bg-blue-600', 'text-white', 'shadow-lg');
      activeNavBtn.classList.remove('text-slate-400', 'hover:bg-slate-800');
    }

    // Cuộn lên đầu trang mượt mà
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Khởi tạo nội dung tương ứng theo tab
    if (tabName === 'home') {
      this.renderHome();
    } else if (tabName === 'tower') {
      this.renderTowerMap();
    } else if (tabName === 'speed') {
      game.startSpeedSprint();
    } else if (tabName === 'topics') {
      this.renderTopicsList();
    } else if (tabName === 'pvp') {
      game.startPvP(5);
    } else if (tabName === 'exams') {
      this.renderExamsList();
    } else if (tabName === 'cheatsheet') {
      this.renderCheatsheet();
    } else if (tabName === 'leaderboard') {
      this.renderLeaderboard();
    } else if (tabName === 'teacher') {
      this.renderTeacherDashboard();
    }

    setTimeout(() => game.renderMath(), 50);
  }

  // ==============================================================
  // RENDER TRANG CHỦ (DASHBOARD)
  // ==============================================================
  renderHome() {
    const container = document.getElementById('home-content');
    if (!container) return;

    const p = storage.profile;
    const allQuestions = storage.getAllQuestions();
    const answeredCount = Object.keys(p.answeredQuestions).length;

    container.innerHTML = `
      <!-- Banner Chào Mừng & Hành Động Chính -->
      <div class="relative rounded-3xl p-6 md:p-10 glass-panel border border-blue-500/30 overflow-hidden shadow-2xl bg-gradient-to-r from-blue-950/70 via-indigo-950/50 to-slate-900/80 mb-8">
        <div class="absolute -right-10 -bottom-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -left-10 -top-10 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10 max-w-2xl">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold mb-3">
            <span>🔥 Chuỗi ngày ôn luyện:</span>
            <span class="text-amber-400 font-extrabold">${p.streak} ngày</span>
          </div>
          <h1 class="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
            Chinh Phục <span class="bg-gradient-to-r from-blue-400 via-cyan-300 to-amber-300 bg-clip-text text-transparent">Toán 9 Cực Đỉnh</span>
          </h1>
          <p class="text-slate-300 text-sm md:text-base mt-3 leading-relaxed">
            Học mà chơi, chơi mà học! Vượt ải boss, thi đấu tốc độ, làm chủ định lý Vi-ét, căn thức, hệ phương trình và bứt phá điểm 9-10 vào lớp 10!
          </p>

          <div class="flex flex-wrap gap-4 mt-6">
            <button onclick="app.showTab('tower')" class="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-extrabold text-sm md:text-base shadow-xl shadow-orange-500/25 flex items-center gap-2 transform hover:-translate-y-0.5 transition">
              <span>🏰 LEO THÁP TRI THỨC</span>
              <span class="text-xs bg-black/30 px-2 py-0.5 rounded-full">Tầng ${p.highestFloor}/10</span>
            </button>
            <button onclick="app.showTab('speed')" class="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-sm md:text-base shadow-xl shadow-cyan-500/25 flex items-center gap-2 transform hover:-translate-y-0.5 transition">
              <span>⚡ THỬ THÁCH 60 GIÂY</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Thống kê nhanh của người học -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div class="p-5 rounded-2xl glass-card border border-slate-700/60">
          <div class="text-slate-400 text-xs font-semibold uppercase">Cấp độ hiện tại</div>
          <div class="text-3xl font-black text-amber-400 mt-1">Cấp ${p.level}</div>
          <div class="text-[11px] text-slate-500 mt-1">Chiến Binh Toán 9</div>
        </div>

        <div class="p-5 rounded-2xl glass-card border border-slate-700/60">
          <div class="text-slate-400 text-xs font-semibold uppercase">Câu hỏi đã làm</div>
          <div class="text-3xl font-black text-cyan-400 mt-1">${answeredCount}/${allQuestions.length}</div>
          <div class="text-[11px] text-slate-500 mt-1">Ngân hàng phong phú</div>
        </div>

        <div class="p-5 rounded-2xl glass-card border border-slate-700/60">
          <div class="text-slate-400 text-xs font-semibold uppercase">Tháp Tri Thức</div>
          <div class="text-3xl font-black text-rose-400 mt-1">Tầng ${p.highestFloor}</div>
          <div class="text-[11px] text-slate-500 mt-1">Mục tiêu: Đỉnh Tháp 10</div>
        </div>

        <div class="p-5 rounded-2xl glass-card border border-slate-700/60">
          <div class="text-slate-400 text-xs font-semibold uppercase">Kỷ Lục Tốc Độ</div>
          <div class="text-3xl font-black text-emerald-400 mt-1">${p.speedHighScore || 0} pts</div>
          <div class="text-[11px] text-slate-500 mt-1">Phản xạ nhẩm tính</div>
        </div>
      </div>

      <!-- Lối vào các chế độ chơi cực hot -->
      <h2 class="text-xl font-black text-white mb-4 flex items-center gap-2">
        <span>🎮 CÁC CHẾ ĐỘ ÔN LUYỆN ĐẶC SẮC</span>
      </h2>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Card 1: Chuyên đề GDPT 2018 -->
        <div onclick="app.showTab('topics')" class="p-6 rounded-3xl glass-card border border-indigo-500/30 hover:border-indigo-400 cursor-pointer group">
          <div class="w-14 h-14 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition">
            🗺️
          </div>
          <h3 class="text-lg font-black text-white group-hover:text-indigo-300 transition">Hành Trình Chuyên Đề</h3>
          <p class="text-xs text-slate-400 mt-2 leading-relaxed">
            10 chuyên đề chuẩn chương trình mới GDPT 2018 (Căn thức, Hệ PT, Lượng giác, Đường tròn, Parabol, Vi-ét...).
          </p>
          <div class="mt-4 text-xs font-bold text-indigo-400 flex items-center gap-1">
            Bắt đầu khám phá ➔
          </div>
        </div>

        <!-- Card 2: Song Đấu 1v1 -->
        <div onclick="app.showTab('pvp')" class="p-6 rounded-3xl glass-card border border-rose-500/30 hover:border-rose-400 cursor-pointer group">
          <div class="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition">
            ⚔️
          </div>
          <h3 class="text-lg font-black text-white group-hover:text-rose-300 transition">Song Đấu 1v1 (2 Bạn)</h3>
          <p class="text-xs text-slate-400 mt-2 leading-relaxed">
            Hai bạn cùng ngồi chung 1 máy tính bấm phím nhanh hoặc so tài trên lớp học! Cực kỳ kịch tính và sôi động!
          </p>
          <div class="mt-4 text-xs font-bold text-rose-400 flex items-center gap-1">
            Thách đấu ngay ➔
          </div>
        </div>

        <!-- Card 3: Đề thi thật Học Kỳ I Nghĩa An -->
        <div onclick="app.showTab('exams')" class="p-6 rounded-3xl glass-card border border-emerald-500/30 hover:border-emerald-400 cursor-pointer group">
          <div class="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition">
            📜
          </div>
          <h3 class="text-lg font-black text-white group-hover:text-emerald-300 transition">Luyện Đề Thi Học Kỳ & Tuyển Sinh</h3>
          <p class="text-xs text-slate-400 mt-2 leading-relaxed">
            Đề thi học kỳ 2025-2026 chính thức (Trắc nghiệm, Đúng/Sai, Điền số và Lời giải tự luận chi tiết).
          </p>
          <div class="mt-4 text-xs font-bold text-emerald-400 flex items-center gap-1">
            Làm bài thi thử ➔
          </div>
        </div>
      </div>
    `;
  }

  // ==============================================================
  // RENDER BẢN ĐỒ THÁP TRI THỨC (TOWER MAP)
  // ==============================================================
  renderTowerMap() {
    const container = document.getElementById('tower-content');
    if (!container) return;

    const highest = storage.profile.highestFloor || 1;

    container.innerHTML = `
      <div id="tower-arena">
        <!-- Giao diện chọn tầng -->
        <div class="text-center max-w-xl mx-auto mb-8">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold mb-2">
            🏆 THÁP TRI THỨC TOÁN 9 (10 TẦNG)
          </div>
          <h2 class="text-3xl font-black text-white">CHỌN TẦNG THÁP ĐỂ KHIÊU CHIẾN</h2>
          <p class="text-slate-400 text-xs mt-2">Hạ gục quái vật toán học từng tầng để mở khóa cổng tháp tiếp theo và nhận danh hiệu Chiến Thần!</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          ${TOWER_FLOORS.map(f => {
            const isUnlocked = f.floor <= highest;
            const isPassed = f.floor < highest;
            return `
              <div class="rounded-3xl p-5 glass-card border ${isUnlocked ? 'border-amber-500/40 bg-slate-900/80 hover:scale-105' : 'border-slate-800 bg-slate-950/40 opacity-60'} transition cursor-pointer flex flex-col justify-between"
                ${isUnlocked ? `onclick="game.startTowerFloor(${f.floor})"` : ''}>
                <div>
                  <div class="flex justify-between items-center mb-3">
                    <span class="text-xs font-bold px-2 py-0.5 rounded-full ${isPassed ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : (isUnlocked ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-slate-800 text-slate-500')}">
                      TẦNG ${f.floor}
                    </span>
                    <span>${isPassed ? '✅' : (isUnlocked ? '⚔️' : '🔒')}</span>
                  </div>
                  <div class="text-5xl text-center my-3">${f.bossAvatar}</div>
                  <h3 class="font-extrabold text-white text-center text-sm">${f.boss}</h3>
                  <p class="text-[11px] text-slate-400 text-center mt-1 line-clamp-2">${f.topic}</p>
                </div>

                <div class="mt-4 pt-3 border-t border-slate-800 text-center">
                  ${isUnlocked ? `
                    <button class="w-full py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-black text-xs shadow-md">
                      ${isPassed ? 'Đấu Lại ⚔️' : 'Vượt Ải Ngay ➔'}
                    </button>
                  ` : `
                    <span class="text-xs text-slate-500 font-medium">Chưa mở khóa</span>
                  `}
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  // ==============================================================
  // RENDER DANH SÁCH CHUYÊN ĐỀ GDPT 2018 (TOPICS)
  // ==============================================================
  renderTopicsList() {
    const container = document.getElementById('topics-content');
    if (!container) return;

    const allQs = storage.getAllQuestions();

    container.innerHTML = `
      <div id="topic-container">
        <div class="text-center max-w-xl mx-auto mb-8">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold mb-2">
            📚 CHƯƠNG TRÌNH GDPT 2018
          </div>
          <h2 class="text-3xl font-black text-white">CHINH PHỤC THEO CHUYÊN ĐỀ</h2>
          <p class="text-slate-400 text-xs mt-2">Chọn chuyên đề bạn cần củng cố kiến thức để luyện tập từng câu kèm giải thích chi tiết!</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          ${TOPICS.map(top => {
            const topQs = allQs.filter(q => q.topicId === top.id);
            const userProg = storage.profile.topicProgress[top.id] || { correct: 0, total: 0 };
            const percent = userProg.total > 0 ? Math.round((userProg.correct / userProg.total) * 100) : 0;

            return `
              <div onclick="app.startTopicPractice('${top.id}')"
                class="rounded-3xl p-6 glass-card border ${top.borderColor} hover:scale-[1.02] cursor-pointer transition flex flex-col justify-between">
                <div>
                  <div class="flex justify-between items-start mb-3">
                    <span class="w-12 h-12 rounded-2xl bg-gradient-to-r ${top.color} text-white font-bold flex items-center justify-center text-xl shadow-lg">
                      ${top.icon}
                    </span>
                    <span class="text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      ${top.badge}
                    </span>
                  </div>

                  <h3 class="text-lg font-black text-white mt-2">${top.name}</h3>
                  <p class="text-xs text-slate-400 mt-2 leading-relaxed">${top.description}</p>
                </div>

                <div class="mt-6 pt-4 border-t border-slate-800">
                  <div class="flex justify-between text-xs font-bold mb-1">
                    <span class="text-slate-400">Tiến độ chuyên đề:</span>
                    <span class="text-cyan-400">${userProg.correct}/${topQs.length} câu (${percent}%)</span>
                  </div>
                  <div class="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div class="bg-gradient-to-r from-blue-500 to-cyan-400 h-full rounded-full" style="width: ${percent}%"></div>
                  </div>

                  <button class="w-full mt-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-600 transition flex items-center justify-center gap-2">
                    <span>Luyện Tập Chuyên Đề</span>
                    <span>➔</span>
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
    game.renderMath(container);
  }

  // Bắt đầu luyện tập chuyên đề được chọn
  startTopicPractice(topicId) {
    const topic = TOPICS.find(t => t.id === topicId);
    if (!topic) return;

    this.activeTopic = topic;
    const allQs = storage.getAllQuestions();
    this.activeTopicQuestions = allQs.filter(q => q.topicId === topicId);

    if (this.activeTopicQuestions.length === 0) {
      alert('Chuyên đề này đang được cập nhật thêm câu hỏi!');
      return;
    }

    this.topicQuestionIndex = 0;
    this.renderTopicQuestion();
    audio.playClick();
  }

  renderTopicQuestion() {
    const container = document.getElementById('topic-container');
    if (!container) return;

    const q = this.activeTopicQuestions[this.topicQuestionIndex];
    const total = this.activeTopicQuestions.length;

    container.innerHTML = `
      <div class="max-w-2xl mx-auto rounded-3xl p-6 md:p-8 glass-panel border border-slate-700 shadow-2xl">
        <!-- Header chuyên đề -->
        <div class="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500 text-blue-300 font-bold flex items-center justify-center text-sm">
              ${this.activeTopic.icon}
            </span>
            <div>
              <div class="text-xs text-slate-400 font-semibold uppercase">${this.activeTopic.name}</div>
              <h3 class="text-base font-bold text-white">Câu ${this.topicQuestionIndex + 1} / ${total}</h3>
            </div>
          </div>
          <button onclick="app.renderTopicsList()" class="px-3 py-1.5 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700">
            Trở lại danh sách ✖
          </button>
        </div>

        <!-- Nội dung câu hỏi -->
        <div class="text-base md:text-lg font-semibold text-slate-100 mb-6">
          ${q.content}
        </div>

        <!-- 4 Lựa chọn -->
        <div class="space-y-3" id="topic-opts">
          ${q.options.map((opt, idx) => `
            <button onclick="app.handleTopicAnswer(${idx})" id="topic-opt-${idx}"
              class="option-btn w-full text-left p-4 rounded-2xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 text-sm md:text-base font-medium flex items-center gap-3">
              <span class="w-7 h-7 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-bold text-amber-400 shrink-0 text-sm">
                ${['A', 'B', 'C', 'D'][idx]}
              </span>
              <span class="flex-1">${opt}</span>
            </button>
          `).join('')}
        </div>

        <!-- Khung giải thích chi tiết sau khi trả lời -->
        <div id="topic-explanation" class="hidden mt-6 p-5 rounded-2xl text-sm border"></div>

        <!-- Nút câu tiếp theo -->
        <div id="topic-next-btn-box" class="hidden mt-6 flex justify-end">
          <button onclick="app.nextTopicQuestion()" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-extrabold text-sm shadow-lg">
            Câu Tiếp Theo ➔
          </button>
        </div>
      </div>
    `;

    game.renderMath(container);
  }

  handleTopicAnswer(chosenIdx) {
    const q = this.activeTopicQuestions[this.topicQuestionIndex];
    const isCorrect = chosenIdx === q.correctAnswer;
    const expBox = document.getElementById('topic-explanation');
    const nextBtnBox = document.getElementById('topic-next-btn-box');

    // Khóa các nút lựa chọn
    for (let i = 0; i < 4; i++) {
      const b = document.getElementById(`topic-opt-${i}`);
      if (b) b.disabled = true;
    }

    const selectedBtn = document.getElementById(`topic-opt-${chosenIdx}`);
    const correctBtn = document.getElementById(`topic-opt-${q.correctAnswer}`);

    storage.recordAnswer(q.id, q.topicId, isCorrect);

    if (isCorrect) {
      audio.playCorrect();
      if (selectedBtn) selectedBtn.classList.add('selected-correct');
      storage.addExp(q.points || 10, (newLv) => app.showLevelUpModal(newLv));
      storage.checkAchievements((ach) => app.showAchievementNotification(ach));

      if (expBox) {
        expBox.className = 'mt-6 p-5 rounded-2xl text-sm border bg-emerald-950/70 border-emerald-500/40 text-emerald-200 block';
        expBox.innerHTML = `
          <div class="font-bold text-emerald-400 flex items-center gap-2 mb-2">
            <span>🎉 CHÍNH XÁC! (+${q.points || 10} EXP)</span>
          </div>
          <div class="leading-relaxed text-slate-300 font-sans">
            <strong>Hướng dẫn giải chi tiết:</strong><br>
            ${q.explanation.replace(/\n/g, '<br>')}
          </div>
        `;
      }
    } else {
      audio.playWrong();
      if (selectedBtn) selectedBtn.classList.add('selected-wrong');
      if (correctBtn) correctBtn.classList.add('selected-correct');

      if (expBox) {
        expBox.className = 'mt-6 p-5 rounded-2xl text-sm border bg-rose-950/70 border-rose-500/40 text-rose-200 block';
        expBox.innerHTML = `
          <div class="font-bold text-rose-400 flex items-center gap-2 mb-2">
            <span>❌ RẤT TIẾC, CHƯA ĐÚNG!</span>
          </div>
          <div class="leading-relaxed text-slate-300 font-sans">
            <strong>Đáp án chính xác:</strong> ${['A', 'B', 'C', 'D'][q.correctAnswer]}. ${q.options[q.correctAnswer]}<br><br>
            <strong>Lời giải từng bước:</strong><br>
            ${q.explanation.replace(/\n/g, '<br>')}
          </div>
        `;
      }
    }

    if (nextBtnBox) nextBtnBox.classList.remove('hidden');
    game.renderMath(expBox);
    this.updateHeaderStats();
  }

  nextTopicQuestion() {
    this.topicQuestionIndex++;
    if (this.topicQuestionIndex < this.activeTopicQuestions.length) {
      this.renderTopicQuestion();
    } else {
      // Hoàn thành hết câu trong chuyên đề
      audio.playVictory();
      if (window.confetti) confetti({ particleCount: 70, spread: 60 });
      const container = document.getElementById('topic-container');
      if (container) {
        container.innerHTML = `
          <div class="rounded-3xl p-8 glass-panel border border-emerald-500/40 text-center max-w-lg mx-auto shadow-2xl animate-pop-in">
            <div class="text-7xl mb-3">🎓</div>
            <div class="text-xs font-bold text-emerald-400 uppercase tracking-widest">Hoàn Thành Chuyên Đề</div>
            <h2 class="text-2xl font-black text-white mt-1">XUẤT SẮC! BẠN ĐÃ RÈN LUYỆN XONG!</h2>
            <p class="text-slate-300 text-xs mt-2">Toàn bộ câu hỏi trong <strong>${this.activeTopic.name}</strong> đã được bạn hoàn thành!</p>

            <div class="mt-6 flex justify-center gap-3">
              <button onclick="app.renderTopicsList()" class="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-600">
                Chuyên đề khác
              </button>
              <button onclick="app.showTab('tower')" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-extrabold text-xs shadow-lg">
                Khiêu chiến Leo Tháp ➔
              </button>
            </div>
          </div>
        `;
      }
    }
  }

  // ==============================================================
  // RENDER DANH SÁCH ĐỀ THI (REAL EXAMS)
  // ==============================================================
  renderExamsList() {
    const container = document.getElementById('exams-content');
    if (!container) return;

    container.innerHTML = `
      <div id="exam-container">
        <div class="text-center max-w-xl mx-auto mb-8">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold mb-2">
            📜 ĐỀ THI HỌC KỲ I & TUYỂN SINH LỚP 10
          </div>
          <h2 class="text-3xl font-black text-white">LUYỆN THI THỰC CHIẾN CHUẨN ĐỀ BỘ</h2>
          <p class="text-slate-400 text-xs mt-2">Cấu trúc đề thi mới nhất gồm Trắc nghiệm 4 lựa chọn, Trắc nghiệm Đúng/Sai và Lời giải Tự luận chuẩn barem!</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          ${REAL_EXAMS.map(ex => `
            <div class="rounded-3xl p-6 glass-card border border-emerald-500/30 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-3">
                  <span class="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
                    Thời gian: ${ex.duration} phút
                  </span>
                  <span class="text-xs text-slate-400">Năm học 2025 - 2026</span>
                </div>

                <h3 class="text-xl font-black text-white mb-2">${ex.title}</h3>
                <p class="text-xs text-slate-300 mb-4">${ex.school}</p>

                <div class="space-y-2 text-xs text-slate-400 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
                  <div class="flex items-center gap-2">
                    <span class="text-emerald-400">✔</span>
                    <span>Phần I: 10 câu trắc nghiệm khách quan 4 phương án</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <span class="text-emerald-400">✔</span>
                    <span>Phần II: Câu trắc nghiệm Đúng / Sai (4 ý con)</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <span class="text-emerald-400">✔</span>
                    <span>Phần III: Lời giải tự luận bài toán thực tế & BĐT AM-GM</span>
                  </div>
                </div>
              </div>

              <div class="mt-6 flex gap-3">
                <button onclick="app.startRealExam('${ex.id}')" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm shadow-lg shadow-emerald-600/30 transition text-center">
                  Bắt Đầu Làm Đề ➔
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    game.renderMath(container);
  }

  // Bắt đầu làm đề thi thực tế
  startRealExam(examId) {
    const exam = REAL_EXAMS.find(e => e.id === examId);
    if (!exam) return;

    this.activeExam = exam;
    this.examAnswers = {}; // { qNum: chosenIdx }

    const container = document.getElementById('exam-container');
    if (!container) return;

    const sec1 = exam.sections[0]; // Trắc nghiệm 10 câu
    const sec2 = exam.sections[1]; // Đúng sai
    const sec3 = exam.sections[2]; // Tự luận

    container.innerHTML = `
      <div class="max-w-3xl mx-auto rounded-3xl p-6 md:p-8 glass-panel border border-slate-700 shadow-2xl">
        <!-- Header đề thi -->
        <div class="border-b border-slate-700 pb-4 mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <div class="text-xs font-bold text-amber-400 uppercase">${exam.school}</div>
            <h2 class="text-xl md:text-2xl font-black text-white">${exam.title}</h2>
          </div>
          <div class="flex items-center gap-2">
            <button onclick="app.renderExamsList()" class="px-3 py-1.5 rounded-lg text-xs bg-slate-800 text-slate-300 border border-slate-700">
              ✖ Thoát
            </button>
          </div>
        </div>

        <div class="space-y-8">
          <!-- PHẦN I: TRẮC NGHIỆM -->
          <div>
            <div class="bg-blue-950/60 p-3 rounded-xl border border-blue-500/30 font-bold text-blue-300 text-sm mb-4">
              ${sec1.name}
            </div>

            <div class="space-y-6">
              ${sec1.questions.map((q, qIdx) => `
                <div class="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
                  <div class="font-semibold text-slate-100 text-sm md:text-base mb-3">
                    <span class="text-amber-400 font-bold">Câu ${q.number}:</span> ${q.content}
                  </div>
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    ${q.options.map((opt, oIdx) => `
                      <label class="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs md:text-sm font-medium flex items-center gap-2 cursor-pointer transition">
                        <input type="radio" name="exam_q_${q.number}" value="${oIdx}" onchange="app.examAnswers['${q.number}'] = ${oIdx}" class="text-blue-500">
                        <span><strong>${['A', 'B', 'C', 'D'][oIdx]}.</strong> ${opt}</span>
                      </label>
                    `).join('')}
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Nút Nộp Bài -->
          <div class="text-center pt-4 border-t border-slate-800">
            <button onclick="app.submitRealExam()" class="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black text-base shadow-xl shadow-emerald-500/30 transition transform hover:-translate-y-0.5">
              ✅ NỘP BÀI VÀ XEM ĐÁP ÁN CHI TIẾT
            </button>
          </div>

          <!-- PHẦN LỜI GIẢI TỰ LUẬN MẪU (ẨN CHO ĐẾN KHI NỘP BÀI) -->
          <div id="exam-solution-section" class="hidden mt-8 pt-8 border-t border-slate-700 space-y-6">
            <div class="bg-amber-950/60 p-4 rounded-xl border border-amber-500/30 font-bold text-amber-300 text-sm">
              ${sec3.name} - ĐÁP ÁN & BIỂU ĐIỂM CHÍNH THỨC
            </div>
            
            ${sec3.essayQuestions.map(eq => `
              <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800">
                <div class="flex justify-between items-center mb-2">
                  <span class="font-bold text-cyan-400">${eq.number}</span>
                  <span class="text-xs bg-slate-800 px-2 py-0.5 rounded text-amber-400 font-semibold">${eq.score}</span>
                </div>
                <div class="text-slate-200 text-xs leading-relaxed whitespace-pre-line mb-3">${eq.text}</div>
                <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 font-sans leading-relaxed">
                  <strong class="text-emerald-400">Đáp án gợi ý:</strong><br>
                  ${eq.solution.replace(/\n/g, '<br>')}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    game.renderMath(container);
  }

  submitRealExam() {
    const sec1 = this.activeExam.sections[0];
    let correctCount = 0;

    sec1.questions.forEach(q => {
      const chosen = this.examAnswers[q.number];
      if (chosen === q.correctAnswer) {
        correctCount++;
      }
    });

    const score = ((correctCount / sec1.questions.length) * 10).toFixed(1);
    audio.playVictory();
    if (window.confetti) confetti({ particleCount: 80, spread: 60 });

    storage.addExp(correctCount * 15, (newLv) => app.showLevelUpModal(newLv));
    storage.checkAchievements((ach) => app.showAchievementNotification(ach));

    // Hiển thị phần tự luận
    const solSec = document.getElementById('exam-solution-section');
    if (solSec) solSec.classList.remove('hidden');

    alert(`🎉 Bạn đã nộp bài thành công!\nSố câu trắc nghiệm đúng: ${correctCount}/${sec1.questions.length}\nĐiểm trắc nghiệm quy đổi: ${score} / 10 điểm!\nHãy kéo xuống dưới để xem lời giải chi tiết và barem biểu điểm tự luận!`);
    
    game.renderMath(document.getElementById('exam-container'));
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  }

  // ==============================================================
  // RENDER SỔ TAY CÔNG THỨC (CHEATSHEET)
  // ==============================================================
  renderCheatsheet() {
    const container = document.getElementById('cheatsheet-content');
    if (!container) return;

    container.innerHTML = `
      <div class="max-w-4xl mx-auto">
        <div class="text-center mb-8">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold mb-2">
            📖 BÍ KÍP CÔNG THỨC TOÁN 9
          </div>
          <h2 class="text-3xl font-black text-white">SỔ TAY CÔNG THỨC TOÀN DIỆN</h2>
          <p class="text-slate-400 text-xs mt-2">Tổng hợp trọn bộ công thức Đại số, Hình học trọng tâm cho ôn thi học kỳ và tuyển sinh vào 10!</p>

          <!-- Ô tìm kiếm công thức nhanh -->
          <div class="max-w-md mx-auto mt-4">
            <input type="text" id="formula-search" oninput="app.filterCheatsheet(this.value)"
              placeholder="🔍 Tìm nhanh: Vi-et, căn bậc hai, tiếp tuyến, diện tích..."
              class="w-full px-4 py-3 rounded-2xl bg-slate-900/90 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-amber-500 shadow-inner">
          </div>
        </div>

        <div id="formula-list" class="space-y-6">
          ${FORMULA_BOOK.map(cat => `
            <div class="rounded-3xl p-6 glass-panel border border-slate-700/80 formula-cat-card">
              <div class="flex items-center gap-3 border-b border-slate-800 pb-3 mb-4">
                <span class="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-lg">
                  ${cat.icon}
                </span>
                <h3 class="text-lg font-black text-white">${cat.category}</h3>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                ${cat.items.map(item => `
                  <div class="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 formula-item">
                    <h4 class="font-bold text-amber-400 text-sm mb-2">${item.title}</h4>
                    <div class="text-slate-200 text-sm py-1 font-mono">${item.formula}</div>
                    <div class="text-[11px] text-slate-400 mt-2 italic bg-slate-950 p-2 rounded-lg border border-slate-800/80">
                      💡 ${item.note}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    game.renderMath(container);
  }

  filterCheatsheet(query) {
    const q = query.toLowerCase().trim();
    const items = document.querySelectorAll('.formula-item');
    items.forEach(it => {
      const text = it.innerText.toLowerCase();
      if (!q || text.includes(q)) {
        it.style.display = 'block';
      } else {
        it.style.display = 'none';
      }
    });
  }

  // ==============================================================
  // RENDER BẢNG VÀNG & THÀNH TỰU (LEADERBOARD)
  // ==============================================================
  renderLeaderboard() {
    const container = document.getElementById('leaderboard-content');
    if (!container) return;

    const list = storage.getLeaderboard();
    const myProfile = storage.profile;

    container.innerHTML = `
      <div class="max-w-3xl mx-auto space-y-8">
        <div class="text-center mb-6">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold mb-2">
            🏆 BẢNG VÀNG DANH DỰ
          </div>
          <h2 class="text-3xl font-black text-white">TOP CHIẾN THẦN TOÁN 9</h2>
          <p class="text-slate-400 text-xs mt-2">Vinh danh những bạn có thành tích cao nhất trong các bài thi và thử thách tốc độ!</p>
        </div>

        <!-- Danh sách xếp hạng -->
        <div class="rounded-3xl glass-panel border border-slate-700/80 overflow-hidden shadow-2xl">
          <div class="p-4 bg-slate-900/80 border-b border-slate-800 grid grid-cols-12 text-xs font-bold text-slate-400 uppercase">
            <div class="col-span-2 text-center">Hạng</div>
            <div class="col-span-6">Học Sinh</div>
            <div class="col-span-2 text-center">Cấp Độ</div>
            <div class="col-span-2 text-right pr-2">Điểm</div>
          </div>

          <div class="divide-y divide-slate-800/60">
            ${list.map((item, idx) => {
              const medal = idx === 0 ? '🥇' : (idx === 1 ? '🥈' : (idx === 2 ? '🥉' : `#${idx + 1}`));
              return `
                <div class="p-4 grid grid-cols-12 items-center text-sm ${idx < 3 ? 'bg-amber-500/5' : ''}">
                  <div class="col-span-2 text-center font-black ${idx === 0 ? 'text-amber-400 text-lg' : 'text-slate-300'}">
                    ${medal}
                  </div>
                  <div class="col-span-6 flex items-center gap-3">
                    <span class="text-2xl">${item.avatar || '🐱'}</span>
                    <div>
                      <div class="font-bold text-white">${item.name}</div>
                      ${item.streak ? `<div class="text-[10px] text-amber-400">🔥 Chuỗi ${item.streak}</div>` : ''}
                    </div>
                  </div>
                  <div class="col-span-2 text-center">
                    <span class="px-2 py-0.5 rounded-full bg-blue-900/50 text-blue-300 text-xs font-bold border border-blue-700/40">
                      Lv.${item.level}
                    </span>
                  </div>
                  <div class="col-span-2 text-right pr-2 font-black text-amber-400 text-base">
                    ${item.score}
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Danh sách Huy Hiệu / Thành Tựu -->
        <div>
          <h3 class="text-xl font-black text-white mb-4 flex items-center gap-2">
            <span>🎖️ HUY HIỆU ĐÃ MỞ KHÓA</span>
            <span class="text-xs bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
              ${myProfile.unlockedAchievements.length} / ${ACHIEVEMENTS.length}
            </span>
          </h3>

          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            ${ACHIEVEMENTS.map(ach => {
              const isUnlocked = myProfile.unlockedAchievements.includes(ach.id);
              return `
                <div class="p-4 rounded-2xl glass-card border ${isUnlocked ? 'border-amber-500/40 bg-slate-900/80' : 'border-slate-800 bg-slate-950/40 opacity-50'} flex items-center gap-3">
                  <div class="text-3xl ${isUnlocked ? '' : 'grayscale'}">${ach.icon}</div>
                  <div>
                    <div class="font-bold text-sm text-white">${ach.name}</div>
                    <div class="text-[11px] text-slate-400">${ach.desc}</div>
                    <div class="text-[10px] text-amber-400 font-semibold mt-1">+${ach.exp} EXP</div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // ==============================================================
  // GÓC GIÁO VIÊN: THÊM CÂU HỎI & IN ĐỀ THI (TEACHER HUB)
  // ==============================================================
  renderTeacherDashboard() {
    const container = document.getElementById('teacher-content');
    if (!container) return;

    const customQs = storage.getCustomQuestions();

    container.innerHTML = `
      <div class="max-w-4xl mx-auto space-y-8">
        <div class="text-center mb-6">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold mb-2">
            👨‍🏫 KHÔNG GIAN DÀNH CHO THẦY CÔ
          </div>
          <h2 class="text-3xl font-black text-white">QUẢN LÝ ĐỀ THI & CÂU HỎI</h2>
          <p class="text-slate-400 text-xs mt-2">Thầy/Cô có thể tạo thêm câu hỏi trắc nghiệm mới, xuất đề thi ra giấy in hoặc chia sẻ cho học sinh làm bài!</p>
        </div>

        <!-- Các công cụ nhanh cho Giáo viên -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button onclick="app.showAddQuestionModal()" class="p-5 rounded-2xl glass-card border border-blue-500/30 hover:border-blue-400 text-left transition group">
            <div class="text-3xl mb-2 group-hover:scale-110 transition">➕</div>
            <div class="font-bold text-white text-sm">Thêm Câu Hỏi Mới</div>
            <div class="text-[11px] text-slate-400 mt-1">Soạn câu hỏi trắc nghiệm kèm công thức toán LaTeX</div>
          </button>

          <button onclick="window.print()" class="p-5 rounded-2xl glass-card border border-emerald-500/30 hover:border-emerald-400 text-left transition group">
            <div class="text-3xl mb-2 group-hover:scale-110 transition">🖨️</div>
            <div class="font-bold text-white text-sm">In Đề Thi Ra Giấy (A4)</div>
            <div class="text-[11px] text-slate-400 mt-1">Xuất đề thi chuẩn trường lớp kèm barem đáp án</div>
          </button>

          <button onclick="app.exportQuestionsJSON()" class="p-5 rounded-2xl glass-card border border-purple-500/30 hover:border-purple-400 text-left transition group">
            <div class="text-3xl mb-2 group-hover:scale-110 transition">💾</div>
            <div class="font-bold text-white text-sm">Sao Lưu Đề (JSON)</div>
            <div class="text-[11px] text-slate-400 mt-1">Tải xuống file câu hỏi để chuyển sang máy tính khác</div>
          </button>
        </div>

        <!-- Danh sách câu hỏi thầy/cô đã thêm -->
        <div class="rounded-3xl p-6 glass-panel border border-slate-700/80">
          <div class="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <h3 class="font-bold text-white text-base">Câu hỏi tùy chỉnh của Giáo viên (${customQs.length})</h3>
            <button onclick="app.showAddQuestionModal()" class="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow">
              + Soạn câu hỏi
            </button>
          </div>

          ${customQs.length === 0 ? `
            <div class="text-center py-8 text-slate-400 text-xs">
              Thầy/Cô chưa thêm câu hỏi tùy chỉnh nào. Hãy bấm "Thêm Câu Hỏi Mới" để bắt đầu soạn đề riêng cho lớp!
            </div>
          ` : `
            <div class="space-y-4">
              ${customQs.map((q, idx) => `
                <div class="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-start gap-4">
                  <div class="space-y-1">
                    <div class="text-xs font-bold text-cyan-400">${q.title}</div>
                    <div class="text-sm text-slate-200 font-medium">${q.content}</div>
                    <div class="text-xs text-emerald-400 font-semibold">Đáp án đúng: ${['A', 'B', 'C', 'D'][q.correctAnswer]}</div>
                  </div>
                  <button onclick="app.deleteQuestion('${q.id}')" class="px-2.5 py-1 text-xs bg-rose-950 text-rose-300 border border-rose-500/40 rounded-lg hover:bg-rose-900 transition shrink-0">
                    Xóa
                  </button>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      </div>
    `;

    game.renderMath(container);
  }

  // Modal thêm câu hỏi mới
  showAddQuestionModal() {
    const modal = document.getElementById('modal-container');
    if (!modal) return;

    modal.innerHTML = `
      <div class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full shadow-2xl animate-pop-in max-h-[90vh] overflow-y-auto">
          <div class="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
            <h3 class="font-black text-white text-lg">Soạn Câu Hỏi Trắc Nghiệm Mới</h3>
            <button onclick="document.getElementById('modal-container').innerHTML=''" class="text-slate-400 hover:text-white">✖</button>
          </div>

          <form id="add-q-form" onsubmit="app.saveNewQuestion(event)" class="space-y-4 text-xs">
            <div>
              <label class="block text-slate-300 font-semibold mb-1">Chủ đề câu hỏi:</label>
              <select id="new-q-topic" class="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white">
                ${TOPICS.map(t => `<option value="${t.id}">${t.name}</option>`).join('')}
              </select>
            </div>

            <div>
              <label class="block text-slate-300 font-semibold mb-1">Tiêu đề / Dạng bài:</label>
              <input type="text" id="new-q-title" placeholder="VD: Giải hệ phương trình bằng phương pháp thế" required
                class="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white">
            </div>

            <div>
              <label class="block text-slate-300 font-semibold mb-1">Nội dung câu hỏi (hỗ trợ ký hiệu LaTeX: $x^2, \\sqrt{x}$):</label>
              <textarea id="new-q-content" rows="3" placeholder="Nhập câu hỏi tại đây..." required
                class="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"></textarea>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-slate-300 font-semibold mb-1">Phương án A:</label>
                <input type="text" id="new-q-opt-0" required class="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white">
              </div>
              <div>
                <label class="block text-slate-300 font-semibold mb-1">Phương án B:</label>
                <input type="text" id="new-q-opt-1" required class="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white">
              </div>
              <div>
                <label class="block text-slate-300 font-semibold mb-1">Phương án C:</label>
                <input type="text" id="new-q-opt-2" required class="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white">
              </div>
              <div>
                <label class="block text-slate-300 font-semibold mb-1">Phương án D:</label>
                <input type="text" id="new-q-opt-3" required class="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white">
              </div>
            </div>

            <div>
              <label class="block text-slate-300 font-semibold mb-1">Đáp án đúng:</label>
              <select id="new-q-correct" class="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white">
                <option value="0">Phương án A</option>
                <option value="1">Phương án B</option>
                <option value="2">Phương án C</option>
                <option value="3">Phương án D</option>
              </select>
            </div>

            <div>
              <label class="block text-slate-300 font-semibold mb-1">Lời giải chi tiết:</label>
              <textarea id="new-q-explain" rows="2" placeholder="Hướng dẫn giải từng bước..."
                class="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"></textarea>
            </div>

            <div class="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button type="button" onclick="document.getElementById('modal-container').innerHTML=''" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300">
                Hủy bỏ
              </button>
              <button type="submit" class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
                Lưu Câu Hỏi
              </button>
            </div>
          </form>
        </div>
      </div>
    `;
  }

  saveNewQuestion(e) {
    e.preventDefault();
    const topicId = document.getElementById('new-q-topic').value;
    const title = document.getElementById('new-q-title').value;
    const content = document.getElementById('new-q-content').value;
    const opt0 = document.getElementById('new-q-opt-0').value;
    const opt1 = document.getElementById('new-q-opt-1').value;
    const opt2 = document.getElementById('new-q-opt-2').value;
    const opt3 = document.getElementById('new-q-opt-3').value;
    const correct = parseInt(document.getElementById('new-q-correct').value, 10);
    const explain = document.getElementById('new-q-explain').value || 'Không có giải thích chi tiết.';

    storage.addCustomQuestion({
      topicId: topicId,
      title: title,
      content: content,
      options: [opt0, opt1, opt2, opt3],
      correctAnswer: correct,
      explanation: explain,
      difficulty: 'medium',
      points: 15
    });

    document.getElementById('modal-container').innerHTML = '';
    alert('✅ Đã lưu câu hỏi thành công vào ngân hàng đề!');
    this.renderTeacherDashboard();
  }

  deleteQuestion(id) {
    if (confirm('Thầy/Cô có chắc chắn muốn xóa câu hỏi này?')) {
      storage.deleteCustomQuestion(id);
      this.renderTeacherDashboard();
    }
  }

  exportQuestionsJSON() {
    const all = storage.getAllQuestions();
    const blob = new Blob([JSON.stringify(all, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Ngan_Hang_Cau_Hoi_Toan_9_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  }

  // ==============================================================
  // THÔNG BÁO LEVEL UP & THÀNH TỰU
  // ==============================================================
  showLevelUpModal(newLevel) {
    audio.playLevelUp();
    if (window.confetti) {
      confetti({ particleCount: 120, spread: 80, origin: { y: 0.5 } });
    }

    const modal = document.getElementById('modal-container');
    if (!modal) return;

    modal.innerHTML = `
      <div class="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
        <div class="bg-gradient-to-b from-slate-900 to-indigo-950 border-2 border-amber-500 rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl animate-pop-in">
          <div class="text-7xl mb-3 animate-float">🎉</div>
          <div class="text-xs font-black text-amber-400 uppercase tracking-widest">CHÚC MỪNG THĂNG CẤP!</div>
          <h2 class="text-4xl font-black text-white mt-1">CẤP ĐỘ ${newLevel}</h2>
          <p class="text-slate-300 text-xs mt-3 leading-relaxed">
            Bạn đã mở khóa thêm nhiều thử thách mới và phần thưởng giá trị! Hãy tiếp tục rèn luyện để chạm đỉnh tháp nhé!
          </p>

          <button onclick="document.getElementById('modal-container').innerHTML=''" class="mt-6 w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-black text-sm shadow-xl shadow-amber-500/30">
            Tuyệt Vời! Nhận Thưởng ➔
          </button>
        </div>
      </div>
    `;
    this.updateHeaderStats();
  }

  showAchievementNotification(ach) {
    audio.playVictory();
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-slate-900/95 border-2 border-amber-500 text-white shadow-2xl flex items-center gap-3 animate-pop-in';
    toast.innerHTML = `
      <div class="text-3xl">${ach.icon}</div>
      <div>
        <div class="text-[10px] uppercase font-bold text-amber-400">HUY HIỆU MỚI!</div>
        <div class="font-extrabold text-sm">${ach.name}</div>
        <div class="text-xs text-slate-400">+${ach.exp} EXP</div>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
  }

  // Bật / Tắt âm thanh
  initAudioToggle() {
    const btn = document.getElementById('sound-toggle-btn');
    if (!btn) return;

    btn.onclick = () => {
      const state = audio.toggle();
      btn.innerText = state ? '🔊 Bật' : '🔇 Tắt';
      btn.className = state ? 'px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-600/30 text-blue-300 border border-blue-500/40 transition' : 'px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700 transition';
    };
  }

  // Đổi tên hoặc avatar người học
  showProfileModal() {
    const p = storage.profile;
    const modal = document.getElementById('modal-container');
    if (!modal) return;

    modal.innerHTML = `
      <div class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-sm w-full shadow-2xl animate-pop-in">
          <div class="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
            <h3 class="font-bold text-white text-base">Hồ Sơ Học Sinh</h3>
            <button onclick="document.getElementById('modal-container').innerHTML=''" class="text-slate-400 hover:text-white">✖</button>
          </div>

          <div class="space-y-4">
            <div>
              <label class="block text-xs text-slate-400 mb-1">Tên của bạn:</label>
              <input type="text" id="edit-player-name" value="${p.name}" class="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm">
            </div>

            <div>
              <label class="block text-xs text-slate-400 mb-2">Chọn Linh Vật (Avatar):</label>
              <div class="grid grid-cols-4 gap-2">
                ${AVATARS.map(av => {
                  const isUnlocked = p.unlockedAvatars.includes(av.id) || p.level >= av.unlockLevel;
                  return `
                    <button onclick="${isUnlocked ? `app.selectAvatar('${av.icon}')` : ''}"
                      class="p-2.5 rounded-xl border text-center ${p.avatar === av.icon ? 'border-amber-400 bg-amber-500/20' : 'border-slate-800 bg-slate-800/60'} ${isUnlocked ? 'hover:scale-105' : 'opacity-40 cursor-not-allowed'} transition">
                      <div class="text-2xl">${av.icon}</div>
                      <div class="text-[9px] text-slate-400 mt-1">${isUnlocked ? av.name.slice(0, 7) : `Lv.${av.unlockLevel}`}</div>
                    </button>
                  `;
                }).join('')}
              </div>
            </div>

            <button onclick="app.saveProfile()" class="w-full mt-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow">
              Lưu Thay Đổi
            </button>
          </div>
        </div>
      </div>
    `;
  }

  selectAvatar(icon) {
    storage.profile.avatar = icon;
    storage.saveProfile();
    this.updateHeaderStats();
    this.showProfileModal();
  }

  saveProfile() {
    const input = document.getElementById('edit-player-name');
    if (input && input.value.trim()) {
      storage.profile.name = input.value.trim();
      storage.saveProfile();
      this.updateHeaderStats();
    }
    document.getElementById('modal-container').innerHTML = '';
  }
}

const app = new AppController();
window.onload = () => app.init();
